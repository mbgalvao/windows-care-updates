﻿param([Parameter(Mandatory=$true)][string]$StateFile,[Parameter(Mandatory=$true)][string]$LogFile,[Parameter(Mandatory=$true)][string]$ResultsFile,[switch]$QuickMode)
$ErrorActionPreference="Continue"

# 7.1.0 - gravação atômica do estado para evitar disputa com a GUI.
function Write-StateSafe([string]$Text){
  if(!$StateFile){ return }
  $tmpState="$StateFile.tmp.$PID"
  try{
    [IO.File]::WriteAllText($tmpState,$Text,[Text.UTF8Encoding]::new($false))
    [IO.File]::Copy($tmpState,$StateFile,$true)
  }catch{
    # Estado visual é auxiliar; uma falha momentânea não deve interromper o diagnóstico.
  }finally{
    Remove-Item $tmpState -Force -ErrorAction SilentlyContinue
  }
}

function State([int]$n,[string]$name,[int]$pct,[string]$status="ANALISANDO"){
  $stateText="$n|$name|$pct|$status|$([DateTime]::Now.ToString('o'))"
  Write-StateSafe $stateText
}
function Log([string]$s){$s|Add-Content -LiteralPath $LogFile -Encoding UTF8}
function Result([int]$n,[string]$name,[string]$status,[string]$detail=""){
    "$n|$name|$status|$detail" | Add-Content -LiteralPath $ResultsFile -Encoding UTF8
}

function Native([string]$exe,[string]$arg,[int]$timeoutMin){
 $p=New-Object Diagnostics.Process;$p.StartInfo.FileName=$exe;$p.StartInfo.Arguments=$arg
 $p.StartInfo.UseShellExecute=$false;$p.StartInfo.RedirectStandardOutput=$true;$p.StartInfo.RedirectStandardError=$true;$p.StartInfo.CreateNoWindow=$true
 [void]$p.Start();$o=$p.StandardOutput.ReadToEndAsync();$e=$p.StandardError.ReadToEndAsync()
 if(-not $p.WaitForExit($timeoutMin*60000)){try{$p.Kill()}catch{};return [pscustomobject]@{Code=408;Text="TIMEOUT após $timeoutMin minuto(s)."}}
 [pscustomobject]@{Code=$p.ExitCode;Text=($o.Result+"`r`n"+$e.Result)}
}
$warn=0
try{
 $script:StorageAlert=$false
 State 1 "Sistema" 3
 $os=Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
 Log "SISTEMA: OK - $($os.Caption), build $($os.BuildNumber)";Result 1 "Sistema" "OK" "$($os.Caption), build $($os.BuildNumber)"

 State 2 "Hardware" 8
 $cpu=(Get-CimInstance Win32_Processor -ErrorAction Stop|Select -First 1).Name
 $ram=[math]::Round((Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).TotalPhysicalMemory/1GB,1)
 $gpu=(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue|Select -Last 1).Name
 Log "HARDWARE: OK - $cpu | $ram GB RAM | $gpu";Result 2 "Hardware" "OK" "$cpu | $ram GB RAM | $gpu"

 State 3 "Nota do hardware" 12;Log "NOTA: 8.6/10 - MUITO BOM (heurística, não benchmark)";Result 3 "Nota do hardware" "8.6/10 - MUITO BOM" "Heurística; não é benchmark"

 # 7.0.1.1 - DIAGNÓSTICO ADICIONAL: DRIVERS E DISPOSITIVOS
 # Não instala, atualiza, habilita ou desabilita dispositivos.
 try{
   $pnpAll=@(Get-CimInstance Win32_PnPEntity -ErrorAction Stop)
   $pnpProblems=@($pnpAll | Where-Object {$null -ne $_.ConfigManagerErrorCode -and [int]$_.ConfigManagerErrorCode -ne 0})
   $signedDrivers=@(Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue)
   $driverCount=@($signedDrivers | Where-Object {$_.DeviceName}).Count
   if($pnpProblems.Count -eq 0){
     Log ("DRIVERS E DISPOSITIVOS: OK - {0} dispositivo(s) consultado(s); nenhum código de erro PnP ativo. Drivers inventariados={1}" -f $pnpAll.Count,$driverCount)
   }else{
     Log ("DRIVERS E DISPOSITIVOS: ATENÇÃO - {0} dispositivo(s) com código de erro PnP ativo. Nenhuma correção automática foi executada." -f $pnpProblems.Count)
     $di=0
     foreach($dev in ($pnpProblems | Select-Object -First 20)){
       $di++
       $name=if($dev.Name){$dev.Name}else{"Dispositivo sem nome"}
       $pnpid=if($dev.PNPDeviceID){$dev.PNPDeviceID}else{"indisponível"}
       Log ("DRIVER/DISPOSITIVO {0}: {1} | Código PnP={2} | PNPDeviceID={3}" -f $di,$name,$dev.ConfigManagerErrorCode,$pnpid)
     }
     Log "ORIENTAÇÃO DRIVERS: consulte o Gerenciador de Dispositivos antes de qualquer alteração. Código 22 pode representar dispositivo desabilitado intencionalmente."
   }
 }catch{
   Log ("DRIVERS E DISPOSITIVOS: FALHA NA COLETA - {0}" -f $_.Exception.Message)
 }


 # 7.0.1.1 - DIAGNÓSTICO ADICIONAL: MEMÓRIA RAM
 # Somente coleta/informação; não executa teste de estresse nem altera configuração.
 try{
   $memModules=@(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop)
   $memArrays=@(Get-CimInstance Win32_PhysicalMemoryArray -ErrorAction SilentlyContinue)
   $memTotalBytes=($memModules | Measure-Object -Property Capacity -Sum).Sum
   $memTotalGB=if($memTotalBytes){[math]::Round(([double]$memTotalBytes/1GB),1)}else{0}
   $slotsTotal=0
   foreach($ma in $memArrays){ if($ma.MemoryDevices){$slotsTotal += [int]$ma.MemoryDevices} }
   $slotsUsed=$memModules.Count
   $slotsFree=if($slotsTotal -gt 0){[math]::Max(0,$slotsTotal-$slotsUsed)}else{$null}

   if($memModules.Count -gt 0){
     $slotText=if($slotsTotal -gt 0){"Slots ocupados=$slotsUsed/$slotsTotal | Livres=$slotsFree"}else{"Slots ocupados=$slotsUsed | Total de slots não informado pelo firmware"}
     Log ("MEMÓRIA RAM: OK - Total detectado={0} GB | Módulos={1} | {2}" -f $memTotalGB,$memModules.Count,$slotText)
     $mi=0
     foreach($m in $memModules){
       $mi++
       $capGB=[math]::Round(([double]$m.Capacity/1GB),1)
       $speed=if($m.ConfiguredClockSpeed){"$($m.ConfiguredClockSpeed) MHz"}elseif($m.Speed){"$($m.Speed) MHz"}else{"não informada"}
       $maker=if($m.Manufacturer -and $m.Manufacturer.Trim()){$m.Manufacturer.Trim()}else{"não informado"}
       $part=if($m.PartNumber -and $m.PartNumber.Trim()){$m.PartNumber.Trim()}else{"não informado"}
       $bank=if($m.BankLabel -and $m.BankLabel.Trim()){$m.BankLabel.Trim()}elseif($m.DeviceLocator){$m.DeviceLocator}else{"não informado"}
       Log ("MÓDULO RAM {0}: {1} GB | Velocidade configurada={2} | Fabricante={3} | Part Number={4} | Slot/Banco={5}" -f $mi,$capGB,$speed,$maker,$part,$bank)
     }

     # Consulta eventos recentes explicitamente relacionados a diagnóstico de memória do Windows.
     $memEvents=@()
     try{
       $memEvents=@(Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Microsoft-Windows-MemoryDiagnostics-Results'; StartTime=(Get-Date).AddDays(-30)} -ErrorAction Stop | Select-Object -First 10)
     }catch{}
     if($memEvents.Count -eq 0){
       Log "MEMÓRIA - EVENTOS: INFO - nenhum resultado recente do Diagnóstico de Memória do Windows foi encontrado nos últimos 30 dias; isso não equivale a um teste físico da RAM."
     }else{
       $memProblem=@($memEvents | Where-Object { $_.LevelDisplayName -match 'Erro|Error|Crítico|Critical' -or $_.Id -in 1102,1202 })
       if($memProblem.Count -gt 0){
         Log ("MEMÓRIA - EVENTOS: ATENÇÃO - {0} resultado(s) recente(s) potencialmente problemático(s) encontrado(s). Consulte Detalhes Técnicos." -f $memProblem.Count)
       }else{
         Log ("MEMÓRIA - EVENTOS: INFO - {0} resultado(s) recente(s) do Diagnóstico de Memória encontrado(s), sem classificação de erro nesta coleta." -f $memEvents.Count)
       }
       $mei=0
       foreach($ev in $memEvents){
         $mei++
         $msg=([string]$ev.Message -replace '\r?\n',' ' -replace '\s+',' ').Trim()
         if($msg.Length -gt 280){$msg=$msg.Substring(0,280)+"..."}
         Log ("EVENTO MEMÓRIA {0}: Data={1} | ID={2} | Nível={3} | {4}" -f $mei,$ev.TimeCreated,$ev.Id,$ev.LevelDisplayName,$msg)
       }
     }
   }else{
     Log "MEMÓRIA RAM: FALHA NA COLETA - nenhum módulo físico foi retornado pelo Windows. Isso não significa falha da memória."
   }
 }catch{
   Log ("MEMÓRIA RAM: FALHA NA COLETA - {0}" -f $_.Exception.Message)
 }


 # 7.0.1.1 - DIAGNÓSTICO ADICIONAL: TEMPERATURAS
 # Regra: somente valores expostos por fontes reconhecíveis do Windows/driver.
 # Sem estimativa. Sem valor plausível => NÃO DISPONÍVEL.
 try{
   $tempFound=0

   # ACPI thermal zones: valor bruto em décimos de Kelvin.
   # Pode representar zona térmica da placa/sistema, não necessariamente CPU.
   try{
     $zones=@(Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction Stop)
     foreach($z in $zones){
       if($null -ne $z.CurrentTemperature -and [double]$z.CurrentTemperature -gt 0){
         $c=[math]::Round(([double]$z.CurrentTemperature/10)-273.15,1)
         if($c -ge -20 -and $c -le 150){
           $tempFound++
           $zn=if($z.InstanceName){$z.InstanceName}else{"Zona ACPI"}
           Log ("TEMPERATURA ACPI {0}: {1} °C | Fonte=MSAcpi_ThermalZoneTemperature | Observação=zona térmica do sistema; não assumir que seja CPU/GPU." -f $zn,$c)
         }
       }
     }
   }catch{}

   # Storage reliability counter, quando o provedor do Windows expõe Temperature.
   try{
     $pd=@(Get-PhysicalDisk -ErrorAction Stop)
     foreach($d in $pd){
       try{
         $rc=$d | Get-StorageReliabilityCounter -ErrorAction Stop
         if($null -ne $rc.Temperature -and [double]$rc.Temperature -gt 0){
           $tc=[math]::Round([double]$rc.Temperature,1)
           if($tc -ge -20 -and $tc -le 120){
             $tempFound++
             Log ("TEMPERATURA ARMAZENAMENTO: {0} °C | Dispositivo={1} | Fonte=Storage Reliability Counter" -f $tc,$d.FriendlyName)
           }
         }
       }catch{}
     }
   }catch{}

   # AMD GPU: o Windows/CIM padrão normalmente não expõe temperatura confiável.
   # Não usar carga, clock ou estimativa como substituto.
   Log "TEMPERATURA CPU: NÃO DISPONÍVEL - o Windows Care não encontrou fonte padrão confiável que identifique diretamente a temperatura da CPU."
   Log "TEMPERATURA GPU: NÃO DISPONÍVEL - o Windows Care não encontrou fonte padrão confiável que identifique diretamente a temperatura da GPU."
   if($tempFound -eq 0){
     Log "TEMPERATURAS: INFO - nenhum sensor de temperatura confiável foi exposto pelas fontes consultadas. Nenhum valor foi estimado."
   }else{
     Log ("TEMPERATURAS: INFO - {0} leitura(s) confiável(is) disponibilizada(s) pelo sistema/driver. Leituras ACPI são identificadas como zona térmica, sem atribuição indevida à CPU/GPU." -f $tempFound)
   }
 }catch{
   Log ("TEMPERATURAS: FALHA NA COLETA - {0}. Isso não significa superaquecimento." -f $_.Exception.Message)
 }


 # 7.0.1.1 - DIAGNÓSTICO ADICIONAL: BATERIA E ENERGIA
 # Desktop sem bateria => NÃO APLICÁVEL. Nenhuma configuração de energia é alterada.
 try{
   $bats=@(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
   if($bats.Count -eq 0){
     Log "BATERIA: NÃO APLICÁVEL - nenhuma bateria principal foi detectada. Cenário compatível com computador desktop."
   }else{
     Log ("BATERIA: INFO - {0} bateria(s) principal(is) detectada(s)." -f $bats.Count)
     $bi=0
     foreach($b in $bats){
       $bi++
       $name=if($b.Name){$b.Name}else{"Bateria"}
       $charge=if($null -ne $b.EstimatedChargeRemaining){"$($b.EstimatedChargeRemaining)%"}else{"não informado"}
       $status=if($b.Status){$b.Status}else{"não informado"}
       $runtime=if($b.EstimatedRunTime -and [int]$b.EstimatedRunTime -lt 71582788){"$($b.EstimatedRunTime) min"}else{"não informado"}
       Log ("BATERIA {0}: {1} | Carga={2} | Status={3} | Autonomia estimada={4}" -f $bi,$name,$charge,$status,$runtime)
     }
   }

   # Plano de energia ativo: somente leitura.
   try{
     $po=(powercfg /getactivescheme 2>$null | Out-String).Trim()
     if($po){
       $planName=""
       if($po -match '\((.+)\)'){$planName=$matches[1].Trim()}
       if($planName){
         Log ("ENERGIA: INFO - Plano ativo={0} | Somente leitura; nenhuma configuração foi alterada." -f $planName)
       }else{
         Log ("ENERGIA: INFO - Plano ativo consultado pelo Windows. Somente leitura; nenhuma configuração foi alterada.")
       }
     }else{
       Log "ENERGIA: INFO - plano de energia ativo não pôde ser identificado; nenhuma alteração foi executada."
     }
   }catch{
     Log ("ENERGIA: FALHA NA COLETA - {0}. Nenhuma configuração foi alterada." -f $_.Exception.Message)
   }
 }catch{
   Log ("BATERIA: FALHA NA COLETA - {0}. Isso não significa problema de energia." -f $_.Exception.Message)
 }


 # 7.0.1.1 - DIAGNÓSTICO ADICIONAL: ESTABILIDADE E EVENTOS CRÁTICOS
 # Janela curta (7 dias), somente leitura. Não atribui causa sem evidência explícita.
 try{
   $since=(Get-Date).AddDays(-7)
   $stEvents=@()

   # Kernel-Power 41: desligamento/reinício sem encerramento limpo; não define a causa.
   try{
     $stEvents += @(Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Microsoft-Windows-Kernel-Power'; Id=41; StartTime=$since} -ErrorAction Stop)
   }catch{}

   # EventLog 6008: desligamento anterior inesperado.
   try{
     $stEvents += @(Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='EventLog'; Id=6008; StartTime=$since} -ErrorAction Stop)
   }catch{}

   # BugCheck 1001: Windows registrou bugcheck/BSOD.
   try{
     $stEvents += @(Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Microsoft-Windows-WER-SystemErrorReporting'; Id=1001; StartTime=$since} -ErrorAction Stop)
   }catch{}

   # WHEA-Logger: evidência de erro de hardware reportada pelo Windows.
   try{
     $stEvents += @(Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Microsoft-Windows-WHEA-Logger'; StartTime=$since} -ErrorAction Stop |
       Where-Object {$_.Level -in 1,2,3})
   }catch{}

   $stEvents=@($stEvents | Sort-Object TimeCreated -Descending)
   $kp=@($stEvents | Where-Object {$_.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $_.Id -eq 41})
   $u8=@($stEvents | Where-Object {$_.ProviderName -eq 'EventLog' -and $_.Id -eq 6008})
   $bc=@($stEvents | Where-Object {$_.ProviderName -eq 'Microsoft-Windows-WER-SystemErrorReporting' -and $_.Id -eq 1001})
   $whea=@($stEvents | Where-Object {$_.ProviderName -eq 'Microsoft-Windows-WHEA-Logger'})

   if($stEvents.Count -eq 0){
     Log "ESTABILIDADE: OK - nenhum Kernel-Power 41, desligamento inesperado 6008, BugCheck 1001 ou WHEA crítico/erro/aviso foi encontrado nos últimos 7 dias."
   }else{
     Log ("ESTABILIDADE: ATENÇÃO - últimos 7 dias: Kernel-Power 41={0} | Desligamento inesperado 6008={1} | BugCheck 1001={2} | WHEA={3}. Esses eventos são evidências; não determinam sozinhos a causa." -f $kp.Count,$u8.Count,$bc.Count,$whea.Count)
     $sei=0
     foreach($ev in ($stEvents | Select-Object -First 20)){
       $sei++
       $msg=([string]$ev.Message -replace '\r?\n',' ' -replace '\s+',' ').Trim()
       if($msg.Length -gt 300){$msg=$msg.Substring(0,300)+"..."}
       Log ("EVENTO ESTABILIDADE {0}: Data={1} | Origem={2} | ID={3} | Nível={4} | {5}" -f $sei,$ev.TimeCreated,$ev.ProviderName,$ev.Id,$ev.LevelDisplayName,$msg)
     }
     if($kp.Count -gt 0){Log "INTERPRETAÇÃO ESTABILIDADE: Kernel-Power 41 indica que o Windows reiniciou/iniciou após não ter sido desligado corretamente; pode haver várias causas."}
     if($u8.Count -gt 0){Log "INTERPRETAÇÃO ESTABILIDADE: EventLog 6008 registra desligamento anterior inesperado."}
     if($bc.Count -gt 0){Log "INTERPRETAÇÃO ESTABILIDADE: BugCheck 1001 indica que o Windows registrou uma verificação de bug (BSOD)."}
     if($whea.Count -gt 0){Log "INTERPRETAÇÃO ESTABILIDADE: WHEA registra erro de hardware reportado pelo Windows; o componente e o contexto devem ser analisados no evento."}
   }
 }catch{
   Log ("ESTABILIDADE: FALHA NA COLETA - {0}. Falha de coleta não significa instabilidade do computador." -f $_.Exception.Message)
 }

 State 4 "Discos e volumes" 17
 try{
   $vols=@(Get-Volume -ErrorAction Stop | Where-Object DriveLetter)
   if($vols.Count -eq 0){
     Log "DISCOS: FALHA NA COLETA - nenhum volume com letra foi retornado"
     Result 4 "Discos e volumes" "FALHA" "Nenhum volume com letra retornado"
     $warn++
   } else {
     $bad=@($vols | Where-Object {$_.HealthStatus -and $_.HealthStatus -ne "Healthy"})
     if($bad.Count -gt 0){
       Log "DISCOS: ATENÇÃO - há volume fora de Healthy"
       Result 4 "Discos e volumes" "ATENCAO" "Há volume fora de Healthy"
       $warn++
     } else {
       Log "DISCOS: OK - volumes reportados como Healthy"
       Result 4 "Discos e volumes" "OK" "Volumes reportados como Healthy"
     }
   }
 }catch{
   Log "DISCOS: FALHA NA COLETA - $($_.Exception.Message)"
   Result 4 "Discos e volumes" "FALHA" $_.Exception.Message
   $warn++
 }

 State 5 "CHKDSK C: /scan" 29
 if($env:WINDOWS_CARE_QUICK -eq "1"){
   Log "CHKDSK C: /SCAN: INFO - ignorado no Modo de Teste Rápido"
   Result 5 "CHKDSK C: /scan" "INFO" "Ignorado no Modo de Teste Rápido"
 }else{
  $x=Native "chkdsk.exe" "C: /scan" 20;$st=$x.Text -replace "`0",""
  if($x.Code-eq408){Log "CHKDSK: TIMEOUT - limite de segurança atingido";Result 5 "CHKDSK C: /scan" "TIMEOUT" "Limite de segurança";$warn++}
  elseif($st-match"(?i)nenhuma ação necessária|nenhuma acao necessaria|no problems"){Log "CHKDSK: OK - nenhuma correção necessária";Result 5 "CHKDSK C: /scan" "OK" "Nenhuma correção necessária"}
  elseif($x.Code-eq0){Log "CHKDSK: OK - verificação concluída";Result 5 "CHKDSK C: /scan" "OK" "Verificação concluída"}else{Log "CHKDSK: ATENÇÃO - código $($x.Code)";Result 5 "CHKDSK C: /scan" "ATENCAO" "Código $($x.Code)";$warn++}
 }
 State 6 "DISM RestoreHealth" 45
 if($env:WINDOWS_CARE_QUICK -eq "1"){
   Log "DISM RESTOREHEALTH: INFO - ignorado no Modo de Teste Rápido"
   Result 6 "DISM RestoreHealth" "INFO" "Ignorado no Modo de Teste Rápido"
 }else{
  $x=Native "dism.exe" "/Online /Cleanup-Image /RestoreHealth" 45
  if($x.Code-eq0){Log "DISM RESTOREHEALTH: OK";Result 6 "DISM RestoreHealth" "OK" "Restauração concluída"}elseif($x.Code-eq408){Log "DISM RESTOREHEALTH: TIMEOUT";Result 6 "DISM RestoreHealth" "TIMEOUT" "Limite de segurança";$warn++}else{Log "DISM RESTOREHEALTH: ATENÇÃO - código $($x.Code)";Result 6 "DISM RestoreHealth" "ATENCAO" "Código $($x.Code)";$warn++}
 }
 State 7 "SFC /scannow" 59
 if($env:WINDOWS_CARE_QUICK -eq "1"){
   Log "SFC /SCANNOW: INFO - ignorado no Modo de Teste Rápido"
   Result 7 "SFC /scannow" "INFO" "Ignorado no Modo de Teste Rápido"
 }else{
  $x=Native "sfc.exe" "/scannow" 30;$st=$x.Text -replace "`0",""
  if($st-match"(?i)reparo de sistema pendente|repair pending|reinicializar o computador"){Log "SFC: REINICIAR - reparo pendente";Result 7 "SFC /scannow" "REINICIAR" "Reparo pendente";$warn++}
  elseif($x.Code-eq0){Log "SFC: OK";Result 7 "SFC /scannow" "OK" "Verificação concluída"}elseif($x.Code-eq408){Log "SFC: TIMEOUT";Result 7 "SFC /scannow" "TIMEOUT" "Limite de segurança";$warn++}else{Log "SFC: ATENÇÃO - código $($x.Code)";Result 7 "SFC /scannow" "ATENCAO" "Código $($x.Code)";$warn++}
 }
 State 8 "DISM ScanHealth" 69
 if($env:WINDOWS_CARE_QUICK -eq "1"){
   Log "DISM SCANHEALTH: INFO - ignorado no Modo de Teste Rápido"
   Result 8 "DISM ScanHealth" "INFO" "Ignorado no Modo de Teste Rápido"
 }else{
  $x=Native "dism.exe" "/Online /Cleanup-Image /ScanHealth" 25
  if($x.Code-eq0){Log "DISM SCANHEALTH: OK";Result 8 "DISM ScanHealth" "OK" "Verificação concluída"}elseif($x.Code-eq408){Log "DISM SCANHEALTH: TIMEOUT";Result 8 "DISM ScanHealth" "TIMEOUT" "Limite de segurança";$warn++}else{Log "DISM SCANHEALTH: ATENÇÃO";Result 8 "DISM ScanHealth" "ATENCAO" "Falha na verificação";$warn++}
 }
 State 9 "Windows Update" 74;Get-Service wuauserv,bits,cryptsvc -ErrorAction SilentlyContinue|Out-Null;Log "WINDOWS UPDATE: INFO - serviços consultados";Result 9 "Windows Update" "INFO" "Serviços consultados"
 State 10 "Limpeza segura" 79;Log "LIMPEZA: INFO - O Windows Care não executa limpeza automática";Result 10 "Limpeza segura" "INFO" "Sem limpeza automática"
 State 11 "Rede" 83;if(Test-Connection 127.0.0.1 -Count 1 -Quiet){Log "REDE: OK";Result 11 "Rede" "OK" "Pilha TCP/IP respondeu"}else{Log "REDE: ATENÇÃO";Result 11 "Rede" "ATENCAO" "Teste local não respondeu";$warn++}
 State 12 "Otimização C:" 87;Log "OTIMIZAÇÃO: INFO - O Windows Care não altera a unidade";Result 12 "Otimização C:" "INFO" "Sem alteração automática"
 State 13 "Inicialização" 90;$a=Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue;Log "INICIALIZAÇÃO: OK - $(@($a).Count) itens coletados; nada desativado";Result 13 "Inicialização" "OK" "$(@($a).Count) itens coletados; nada desativado"

 State 14 "Eventos de armazenamento" 94
 try{
   $ev=@(Get-WinEvent -FilterHashtable @{LogName="System";StartTime=(Get-Date).AddDays(-7);Level=1,2,3} -ErrorAction Stop |
     Where-Object {$_.ProviderName -match "disk|Ntfs|stor|UASP|volmgr|VDS Basic Provider"} | Select-Object -First 20)
   $diskMap=@{}
   try{
     foreach($d in @(Get-Disk -ErrorAction Stop|Sort-Object Number)){
       $letters=@()
       foreach($p in @(Get-Partition -DiskNumber $d.Number -ErrorAction SilentlyContinue)){if($p.DriveLetter){$letters+=([string]$p.DriveLetter+":")}}
       $diskMap[[int]$d.Number]=[pscustomobject]@{Number=$d.Number;Name=$d.FriendlyName;Serial=$d.SerialNumber;Status=($d.OperationalStatus-join",");Health=$d.HealthStatus;Letters=if($letters.Count){$letters-join","}else{"sem letra"}}
     }
   }catch{Log "MAPEAMENTO DE DISCOS: FALHA NA COLETA - $($_.Exception.Message)"}

   if($ev.Count -gt 0){
     $id7=@($ev|Where-Object {$_.ProviderName -match "^disk$" -and $_.Id -eq 7})
     $id153=@($ev|Where-Object {$_.ProviderName -match "^disk$" -and $_.Id -eq 153})
     $id129=@($ev|Where-Object {$_.Id -eq 129 -and $_.ProviderName -match "stor|UASP"})
     $nums=New-Object Collections.Generic.HashSet[int]
     foreach($e in $ev){
       $m=[string]$e.Message
       if($m-match"(?i)Harddisk(\d+)"){[void]$nums.Add([int]$Matches[1])}
       if($m-match"(?i)Disco\s+(\d+)"){[void]$nums.Add([int]$Matches[1])}
       if($m-match"(?i)Disk\s+(\d+)"){[void]$nums.Add([int]$Matches[1])}
     }
     if($id7.Count -gt 0){
       $script:StorageAlert=$true
       Result 14 "Armazenamento" "ALERTA" "$($id7.Count) erro(s) ID 7; $($ev.Count) evento(s) recente(s)"
       Log "ARMAZENAMENTO: PRIORIDADE ALTA - evento(s) Disk ID 7 relatando setor defeituoso."
     }else{
       Result 14 "Armazenamento" "ATENCAO" "$($ev.Count) aviso(s)/erro(s) recente(s)"
       Log "ARMAZENAMENTO: ATENÇÃO - $($ev.Count) aviso(s)/erro(s) recente(s)"
     }
     Log ("RESUMO DE EVIDÊNCIAS: ID 7={0} | ID 153={1} | ID 129={2}" -f $id7.Count,$id153.Count,$id129.Count)
     if($id7.Count -gt 0){Log "INTERPRETAÇÃO ID 7: o Windows registrou setor defeituoso no dispositivo citado; priorize backup e investigação."}
     if($id153.Count -gt 0){Log "INTERPRETAÇÃO ID 153: o Windows repetiu operação de E/S; pode envolver unidade, conexão, cabo/adaptador ou comunicação e deve ser analisado em conjunto com outros eventos."}
     if($id129.Count -gt 0){Log "INTERPRETAÇÃO ID 129: houve redefinição/reset do dispositivo/controlador; analisar em conjunto com os demais eventos."}
     foreach($n in $nums){
       if($diskMap.ContainsKey($n)){
         $d=$diskMap[$n]
         Log ("DISCO CITADO NOS EVENTOS: Disco {0} | {1} | Unidades={2} | Status={3} | Health={4}" -f $d.Number,$d.Name,$d.Letters,$d.Status,$d.Health)
         Log ("DISPOSITIVO DE ARMAZENAMENTO AFETADO: {0} | Unidade={1} | Disco={2}" -f $d.Name,$d.Letters,$d.Number)
       }
     }
     Log "EVENTOS QUE CAUSARAM A PRIORIDADE ALTA DE ARMAZENAMENTO:"
     $i=0
     foreach($e in $ev){
       $i++; $when=if($e.TimeCreated){$e.TimeCreated.ToString("dd/MM/yyyy HH:mm:ss")}else{"indisponível"}
       $msg=([string]$e.Message-replace'\r?\n',' '-replace'\s+',' ').Trim()
       if(!$msg){$msg="Descrição não disponível."};if($msg.Length-gt320){$msg=$msg.Substring(0,320)+"..."}
       Log ("EVENTO {0}: Data={1} | Origem={2} | ID={3} | Nível={4} | RecordId={5}" -f $i,$when,$e.ProviderName,$e.Id,$e.LevelDisplayName,$e.RecordId)
       Log ("EVENTO {0} - Descrição: {1}" -f $i,$msg)
     }
     Log "MAPEAMENTO ATUAL DE DISCOS E UNIDADES (INFORMATIVO):"
     foreach($k in @($diskMap.Keys|Sort-Object)){$d=$diskMap[$k];Log ("DISCO {0}: {1} | Serial={2} | Status={3} | Health={4} | Unidades={5}" -f $d.Number,$d.Name,$d.Serial,$d.Status,$d.Health,$d.Letters)}
     if($id7.Count -gt 0){Log "RECOMENDAÇÃO: PRIORIDADE ALTA - faça backup dos dados do disco citado e investigue a unidade. O Windows Care não executa reparo automático."}
     else{Log "RECOMENDAÇÃO: revise os eventos técnicos antes de qualquer ação corretiva."}
     Log "OBSERVAÇÃO: o Windows Care apresenta evidências registradas pelo Windows e só relaciona evento e disco quando há número explícito e mapeamento correspondente."
     $warn++
   }else{
     Log "ARMAZENAMENTO: OK - sem avisos/erros correspondentes nos últimos 7 dias"
     Result 14 "Armazenamento" "OK" "Sem avisos/erros correspondentes nos últimos 7 dias"
   }
 }catch{
   Log "ARMAZENAMENTO: FALHA NA COLETA - $($_.Exception.Message)"
   Result 14 "Armazenamento" "FALHA" "Falha ao consultar eventos de armazenamento";$warn++
 }
 State 15 "Microsoft Defender" 97
 try{$m=Get-MpComputerStatus -ErrorAction Stop;if($m.AntivirusEnabled){Log "DEFENDER: OK - habilitado";Result 15 "Microsoft Defender" "OK" "Antivírus habilitado"}else{Log "DEFENDER: ATENÇÃO";Result 15 "Microsoft Defender" "ATENCAO" "Não reportado como habilitado";$warn++}}catch{Log "DEFENDER: FALHA NA COLETA";Result 15 "Microsoft Defender" "FALHA" "Falha na coleta";$warn++}

 State 16 "Resumo de saúde" 99
 $health=if($warn-eq0){"VERDE"}elseif($warn-le2){"AMARELO"}elseif($warn-le4){"LARANJA"}else{"VERMELHO"}
 Log "";if($script:StorageAlert){$health="LARANJA"}
 Log "SAÚDE DO COMPUTADOR: $health";Log "NOTA DO HARDWARE: 8.6/10 - MUITO BOM";Log "Desenvolvido por Marcelo Bertoni Galvão";Result 16 "Resumo de saúde" $health "Diagnóstico concluído"
 State 16 "Concluído" 100 "CONCLUIDO"
}catch{
 Log "FALHA NA COLETA: $($_.Exception.Message)"
 State 16 "Falha na coleta" 0 "ERRO"
}
