﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$base=Split-Path -Parent $MyInvocation.MyCommand.Path;$engine=Join-Path $base "Windows_Care_Engine_9.0_PRO_FINAL.ps1"
$state=Join-Path $env:TEMP ("WC70_"+[guid]::NewGuid().ToString("N")+".state");$log=Join-Path $env:TEMP ("WC70_"+[guid]::NewGuid().ToString("N")+".log");$results=Join-Path $env:TEMP ("WC70_"+[guid]::NewGuid().ToString("N")+".results")

# 7.4.0 - Histórico de Saúde com proteção contra duplicação do mesmo diagnóstico
$historyDir=Join-Path $env:LOCALAPPDATA "WindowsCare"
$historyFile=Join-Path $historyDir "health_history.json"
$script:HistorySummary="Primeiro diagnóstico registrado nesta versão."
$script:HistoryDetail="Nenhum histórico anterior comparável."
$script:HistoryNew7=0;$script:HistoryNew153=0;$script:HistoryNew129=0
$script:CurrentRunId=""
$script:HistoryStatus="SEM HISTÓRICO"
$script:HistoryLastOccurrence="Última ocorrência: não disponível"
$script:HistoryEvolution="Evolução do PC: aguardando diagnóstico comparável."

function Get-StorageSnapshot([string[]]$sourceLines){
  $ev=[string](@($sourceLines | Where-Object {([string]$_) -match '^RESUMO DE EVIDÊNCIAS:'} | Select-Object -First 1))
  $id7=0;$id153=0;$id129=0
  if($ev -match 'ID 7=(\d+)'){$id7=[int]$Matches[1]}
  if($ev -match 'ID 153=(\d+)'){$id153=[int]$Matches[1]}
  if($ev -match 'ID 129=(\d+)'){$id129=[int]$Matches[1]}
  $dev=[string](@($sourceLines | Where-Object {([string]$_) -match '^DISPOSITIVO DE ARMAZENAMENTO AFETADO:'} | Select-Object -First 1))
  $model="";$letter="";$disk="";$serial=""
  if($dev -match '^DISPOSITIVO DE ARMAZENAMENTO AFETADO:\s*(.+?)\s*\|\s*Unidade=([^|]+)\|\s*Disco=(\d+)'){
    $model=$Matches[1].Trim();$letter=$Matches[2].Trim();$disk=$Matches[3].Trim()
    $map=[string](@($sourceLines | Where-Object {([string]$_) -match ("^DISCO\s+"+[regex]::Escape($disk)+":")} | Select-Object -First 1))
    if($map -match 'Serial=([^|]+)'){$serial=$Matches[1].Trim()}
  }
  $events=@()
  foreach($line in @($sourceLines | Where-Object {([string]$_) -match '^EVENTO \d+: Data=.*\| Origem=.*\| ID=(7|153|129)\b'})){
    $t=[string]$line;$rid=0;$eid=0
    if($t -match '\| ID=(7|153|129)\b'){$eid=[int]$Matches[1]}
    if($t -match '\| RecordId=(\d+)\b'){$rid=[long]$Matches[1]}
    $events += [pscustomobject]@{ID=$eid;RecordId=$rid;Key=($t -replace '^EVENTO \d+:\s*','').Trim()}
  }
  [pscustomobject]@{Timestamp=(Get-Date).ToString("o");Model=$model;Letter=$letter;Disk=$disk;Serial=$serial;ID7=$id7;ID153=$id153;ID129=$id129;Events=@($events)}
}

function Update-HealthHistory([string]$health){
  try{
    if(!(Test-Path $historyDir)){New-Item -ItemType Directory -Path $historyDir -Force|Out-Null}
    $tech=@();if(Test-Path $log){$tech=@(Get-Content -LiteralPath $log -ErrorAction SilentlyContinue)}
    $snap=Get-StorageSnapshot $tech
    $runs=@();$schema=0
    if(Test-Path $historyFile){
      try{$obj=Get-Content -LiteralPath $historyFile -Raw -ErrorAction Stop|ConvertFrom-Json
        if($obj.SchemaVersion){$schema=[int]$obj.SchemaVersion};if($obj.Runs){$runs=@($obj.Runs)}
      }catch{$runs=@();$schema=0}
    }
    # 7.4.0 - limpeza conservadora de duplicatas legadas.
    # Remove apenas registros realmente idênticos gravados no mesmo minuto; mantém o registro mais recente.
    if($runs.Count -gt 1){
      $seen=@{};$clean=New-Object System.Collections.ArrayList
      for($di=$runs.Count-1;$di-ge0;$di--){
        $dr=$runs[$di]
        try{$dminute=([datetime]$dr.Timestamp).ToString("yyyy-MM-dd HH:mm")}catch{$dminute=([string]$dr.Timestamp)}
        $dmode=if($dr.Mode){([string]$dr.Mode)}else{"ANTERIOR"}
        $dscore=if($dr.HardwareScore){([string]$dr.HardwareScore)}else{"N/D"}
        $dnew7=if($null -ne $dr.NewID7){([string]$dr.NewID7)}else{"N/D"}
        $dnew153=if($null -ne $dr.NewID153){([string]$dr.NewID153)}else{"N/D"}
        $dnew129=if($null -ne $dr.NewID129){([string]$dr.NewID129)}else{"N/D"}
        $key=($dminute+"|"+(([string]$dr.Health))+"|"+$dmode+"|"+$dscore+"|"+(([string]$dr.Model))+"|"+(([string]$dr.Letter))+"|"+(([string]$dr.Disk))+"|"+(([string]$dr.ID7))+"|"+(([string]$dr.ID153))+"|"+(([string]$dr.ID129))+"|"+$dnew7+"|"+$dnew153+"|"+$dnew129)
        if(-not $seen.ContainsKey($key)){$seen[$key]=$true;[void]$clean.Insert(0,$dr)}
      }
      $runs=@($clean)
    }
    $prev=$null
    if($runs.Count -gt 0){
      for($i=$runs.Count-1;$i-ge0;$i--){
        $r=$runs[$i];$same=$false
        if($snap.Serial -and $r.Serial){$same=(([string]$r.Serial) -eq ([string]$snap.Serial))}
        elseif($snap.Model){$same=(([string]$r.Model) -eq ([string]$snap.Model) -and ([string]$r.Letter) -eq ([string]$snap.Letter))}
        if($same){$prev=$r;break}
      }
    }
    $recordIds=@($snap.Events|Where-Object {$_.RecordId -gt 0}|ForEach-Object {[long]$_.RecordId})
    $maxRecord=if($recordIds.Count){($recordIds|Measure-Object -Maximum).Maximum}else{0}
    if($prev -and $schema -ge 2 -and $prev.MaxRecordId){
      $oldMax=[long]$prev.MaxRecordId
      $newEvents=@($snap.Events|Where-Object {$_.RecordId -gt $oldMax})
      $new7=@($newEvents|Where-Object {$_.ID -eq 7}).Count
      $new153=@($newEvents|Where-Object {$_.ID -eq 153}).Count
      $new129=@($newEvents|Where-Object {$_.ID -eq 129}).Count
      $script:HistoryNew7=$new7;$script:HistoryNew153=$new153;$script:HistoryNew129=$new129
      $script:HistorySummary=if($new7 -gt 0){"NOVO EVENTO: +$new7 ID 7 desde o diagnóstico anterior."}else{"Nenhum novo ID 7 desde o diagnóstico anterior."}
      $script:HistoryDetail=("Anterior: ID 7={0}, ID 153={1}, ID 129={2} | Atual: ID 7={3}, ID 153={4}, ID 129={5} | Novos confirmados: ID 7=+{6}, ID 153=+{7}, ID 129=+{8}" -f $prev.ID7,$prev.ID153,$prev.ID129,$snap.ID7,$snap.ID153,$snap.ID129,$new7,$new153,$new129)
    }elseif($prev){
      $script:HistorySummary="Histórico anterior migrado para o novo método de comparação."
      $script:HistoryDetail=("Referência atual registrada: ID 7={0}, ID 153={1}, ID 129={2}. A partir do próximo diagnóstico, somente RecordId novos serão contados como novos eventos." -f $snap.ID7,$snap.ID153,$snap.ID129)
    }else{
      $script:HistorySummary="Primeiro diagnóstico comparável registrado."
      $script:HistoryDetail=("Atual: ID 7={0}, ID 153={1}, ID 129={2}. A próxima execução poderá identificar eventos realmente novos pelo RecordId do Windows." -f $snap.ID7,$snap.ID153,$snap.ID129)
    }
    # 7.4.0 - resumo visual de evolução; não altera o diagnóstico bruto.
    $newTotal=$script:HistoryNew7+$script:HistoryNew153+$script:HistoryNew129
    if($prev -and $schema -ge 2){
      if($newTotal -gt 0){$script:HistoryStatus="NOVOS EVENTOS";$script:HistoryEvolution=("Evolução do PC: {0} novo(s) evento(s) de armazenamento desde o diagnóstico anterior (ID 7=+{1}, ID 153=+{2}, ID 129=+{3})." -f $newTotal,$script:HistoryNew7,$script:HistoryNew153,$script:HistoryNew129)}
      else{$script:HistoryStatus="ESTÁVEL";$script:HistoryEvolution="Evolução do PC: nenhum novo evento 7/153/129 confirmado desde o diagnóstico anterior; o alerta existente permanece em acompanhamento."}
    }else{$script:HistoryStatus="REFERÊNCIA";$script:HistoryEvolution="Evolução do PC: referência atual registrada; comparação disponível a partir da próxima execução."}
    $latest=@($snap.Events | Where-Object {$_.RecordId -gt 0} | Sort-Object RecordId -Descending | Select-Object -First 1)
    if($latest.Count){
      $le=$latest[0];$dateText=""
      if($le.Key -match '^Data=([^|]+)\|'){$dateText=$Matches[1].Trim()}
      $script:HistoryLastOccurrence=("Última ocorrência registrada: {0} | ID {1} | RecordId {2}" -f $(if($dateText){$dateText}else{"data não disponível"}),$le.ID,$le.RecordId)
    }else{$script:HistoryLastOccurrence="Última ocorrência registrada: nenhuma ocorrência 7/153/129 disponível na coleta atual."}

    $note=[string](@($tech | Where-Object {([string]$_) -match '^NOTA:'} | Select-Object -First 1))
    $hwScore="-";if($note -match 'NOTA:\s*([0-9]+(?:[\.,][0-9]+)?)/10'){$hwScore=$Matches[1].Replace(',', '.')}
    $mode=if($Quick.Checked){"RÁPIDO"}else{"COMPLETO"}
    $runId=if($script:CurrentRunId){$script:CurrentRunId}else{[guid]::NewGuid().ToString("N")}
    # 7.4.0: um RunId identifica uma execução. Se esta rotina for chamada novamente para a mesma execução, substitui o registro em vez de duplicá-lo.
    $runs=@($runs | Where-Object { -not ($_.PSObject.Properties.Name -contains "RunId" -and ([string]$_.RunId) -eq [string]$runId) })
    $entry=[ordered]@{RunId=$runId;Timestamp=$snap.Timestamp;Health=$health;Mode=$mode;HardwareScore=$hwScore;Model=$snap.Model;Letter=$snap.Letter;Disk=$snap.Disk;Serial=$snap.Serial;ID7=$snap.ID7;ID153=$snap.ID153;ID129=$snap.ID129;NewID7=$script:HistoryNew7;NewID153=$script:HistoryNew153;NewID129=$script:HistoryNew129;MaxRecordId=[long]$maxRecord}
    $runs += [pscustomobject]$entry;if($runs.Count -gt 10){$runs=@($runs|Select-Object -Last 10)}
    [ordered]@{SchemaVersion=2;Runs=$runs}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $historyFile -Encoding UTF8
  }catch{$script:HistorySummary="Histórico indisponível nesta execução.";$script:HistoryDetail=$_.Exception.Message}
}

function Normalize-WCHistoryMode([string]$Mode){
  if([string]::IsNullOrWhiteSpace($Mode)){return "ANTERIOR"}
  $m=$Mode.Trim()
  # Corrige registros antigos gravados com caractere de substituição/mojibake.
  if($m -match '^R. PIDO$' -or $m -match '^R.\?PIDO$' -or $m -match '^R.?PIDO$' -or $m -eq 'R�PIDO' -or $m -eq 'RÃ�PIDO'){return "RÁPIDO"}
  if($m -match '^COMPLETO$'){return "COMPLETO"}
  return $m
}

function Get-HistoryViewText {
  $out=New-Object System.Collections.Generic.List[string]
  $out.Add("HISTÓRICO DE SAÚDE - WINDOWS CARE 9.0 PRO - FINAL 5")
  $out.Add("Desenvolvido por Marcelo Bertoni Galvão")
  $out.Add("")
  $out.Add("COMPARAÇÃO ATUAL")
  $out.Add($script:HistorySummary)
  $out.Add($script:HistoryDetail)
  $out.Add("")
  $out.Add("ÚLTIMOS DIAGNÓSTICOS")
  $out.Add("Data/Hora          | Saúde    | Modo     | Nota | ID7 | +7 | ID153 | +153 | ID129 | +129 | Dispositivo")
  $out.Add("-------------------+----------+----------+------+-----+----+-------+------+------+------+------------------------------")
  try{
    if(Test-Path $historyFile){
      $obj=Get-Content -LiteralPath $historyFile -Raw -ErrorAction Stop|ConvertFrom-Json
      $runs=@($obj.Runs|Select-Object -Last 10)
      [array]::Reverse($runs)
      foreach($r in $runs){
        try{$dt=[datetime]$r.Timestamp;$when=$dt.ToString("dd/MM/yyyy HH:mm")}catch{$when=([string]$r.Timestamp)}
        $mode=Normalize-WCHistoryMode ([string]$r.Mode);$score=if($r.HardwareScore -and ([string]$r.HardwareScore) -ne "-"){([string]$r.HardwareScore)}else{"N/D"}
        $n7=if($null -ne $r.NewID7 -and ([string]$r.NewID7) -ne "-"){([string]$r.NewID7)}else{"N/D"};$n153=if($null -ne $r.NewID153 -and ([string]$r.NewID153) -ne "-"){([string]$r.NewID153)}else{"N/D"};$n129=if($null -ne $r.NewID129 -and ([string]$r.NewID129) -ne "-"){([string]$r.NewID129)}else{"N/D"}
        $dev=if($r.Model){(([string]$r.Model)+$(if($r.Letter){" - "+([string]$r.Letter)}else{""}))}else{"não identificado"}
        $out.Add(("{0,-18} | {1,-8} | {2,-8} | {3,4} | {4,3} | {5,-4} | {6,5} | {7,-5} | {8,5} | {9,-5} | {10}" -f $when,([string]$r.Health),$mode,$score,([string]$r.ID7),$(if($n7 -eq "N/D"){"N/D"}else{"+"+$n7}),([string]$r.ID153),$(if($n153 -eq "N/D"){"N/D"}else{"+"+$n153}),([string]$r.ID129),$(if($n129 -eq "N/D"){"N/D"}else{"+"+$n129}),$dev))
      }
    }else{$out.Add("Nenhum histórico local disponível.")}
  }catch{$out.Add("Histórico indisponível: "+$_.Exception.Message)}
  $out.Add("")
  $out.Add("Legenda: +7/+153/+129 = eventos novos confirmados por RecordId desde a execução anterior.")
  $out.Add("Uma redução de contagem não é classificada automaticamente como melhora.")
  $out.Add("Arquivo local: "+$historyFile)
  return ($out -join "`r`n")
}


function Format-CleanupBytes([long]$Bytes){
  if($Bytes -ge 1GB){return ("{0:N2} GB" -f ($Bytes/1GB))}
  if($Bytes -ge 1MB){return ("{0:N1} MB" -f ($Bytes/1MB))}
  if($Bytes -ge 1KB){return ("{0:N1} KB" -f ($Bytes/1KB))}
  return ("{0} B" -f $Bytes)
}
function Get-CleanupFolderBytes([string]$Path,[string]$Filter='*'){
  try{
    if(-not (Test-Path -LiteralPath $Path)){return 0L}
    $sum=(Get-ChildItem -LiteralPath $Path -Filter $Filter -Force -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
    if($null -eq $sum){return 0L}; return [long]$sum
  }catch{return 0L}
}
function Get-CleanupAnalysis {
  $userTemp=[IO.Path]::GetTempPath()
  $winTemp=Join-Path $env:WINDIR 'Temp'
  $wer=Join-Path $env:ProgramData 'Microsoft\Windows\WER\ReportArchive'
  $recycle=Join-Path $env:SystemDrive '$Recycle.Bin'
  return [ordered]@{
    'Temporários do usuário'=(Get-CleanupFolderBytes $userTemp)
    'Temporários do Windows'=(Get-CleanupFolderBytes $winTemp)
    'Relatórios de erro do Windows'=(Get-CleanupFolderBytes $wer)
    'Lixeira'=(Get-CleanupFolderBytes $recycle)
  }
}
function Remove-CleanupContents([string]$Path){
  if(-not (Test-Path -LiteralPath $Path)){return}
  Get-ChildItem -LiteralPath $Path -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}

function Get-StartupInventory {
  $items=New-Object System.Collections.Generic.List[object]
  foreach($spec in @(
    @{Path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run';Source='Registro - Usuário'},
    @{Path='HKLM:\Software\Microsoft\Windows\CurrentVersion\Run';Source='Registro - Sistema'},
    @{Path='HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run';Source='Registro - Sistema 32-bit'}
  )){
    try{
      $key=Get-ItemProperty -LiteralPath $spec.Path -ErrorAction SilentlyContinue
      if($key){
        foreach($prop in $key.PSObject.Properties | Where-Object {$_.Name -notmatch '^PS(Path|ParentPath|ChildName|Drive|Provider)$'}){
          $items.Add([pscustomobject]@{Nome=$prop.Name;Origem=$spec.Source;Comando=[string]$prop.Value;Status='ATIVO'})
        }
      }
    }catch{}
  }
  foreach($folderSpec in @(
    @{Path=[Environment]::GetFolderPath('Startup');Source='Pasta Inicializar - Usuário'},
    @{Path=[Environment]::GetFolderPath('CommonStartup');Source='Pasta Inicializar - Sistema'}
  )){
    try{
      if(Test-Path -LiteralPath $folderSpec.Path){
        foreach($f in Get-ChildItem -LiteralPath $folderSpec.Path -File -ErrorAction SilentlyContinue){
          $items.Add([pscustomobject]@{Nome=$f.BaseName;Origem=$folderSpec.Source;Comando=$f.FullName;Status='ATIVO'})
        }
      }
    }catch{}
  }
  return @($items | Sort-Object Nome,Origem)
}
function Get-InstalledSoftwareInventory {
  $all=New-Object System.Collections.Generic.List[object]
  foreach($rp in @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
  )){
    try{
      foreach($x in Get-ItemProperty $rp -ErrorAction SilentlyContinue){
        if($x.DisplayName){$all.Add([pscustomobject]@{Programa=[string]$x.DisplayName;Versao=if($x.DisplayVersion){[string]$x.DisplayVersion}else{'N/D'};Fabricante=if($x.Publisher){[string]$x.Publisher}else{'N/D'}})}
      }
    }catch{}
  }
  return @($all | Sort-Object Programa,Versao -Unique)
}

$F=New-Object Windows.Forms.Form;$F.Text="Windows Care 9.0 PRO";$F.Size="1000,820";$F.StartPosition="CenterScreen";$F.BackColor=[Drawing.Color]::FromArgb(18,22,28);$F.ForeColor="White";$F.Font="Segoe UI,10"

# FINAL - leitura tolerante do arquivo de estado.
function Read-StateSafe([string]$Path){
  if(!(Test-Path $Path)){ return $null }
  for($i=0;$i -lt 8;$i++){
    try{
      $fs=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)
      try{
        $sr=New-Object IO.StreamReader($fs,[Text.Encoding]::UTF8,$true)
        try{return $sr.ReadToEnd()}finally{$sr.Dispose()}
      }finally{$fs.Dispose()}
    }catch{
      Start-Sleep -Milliseconds 25
    }
  }
  return $null
}

function Label($text,$x,$y,$size,$font="Segoe UI,10"){$o=New-Object Windows.Forms.Label;$o.Text=$text;$o.Location="$x,$y";$o.Size=$size;$o.Font=$font;$F.Controls.Add($o);$o}
$T=Label "WINDOWS CARE 9.0 PRO" 28 18 "450,45" "Segoe UI,22";$C=Label "Desenvolvido por Marcelo Bertoni Galvão  •  VERSÃO 9.0 PRO FINAL 5" 31 61 "450,25";$C.ForeColor="Silver"

$Quick=New-Object System.Windows.Forms.CheckBox
$Quick.Text="TESTE RÁPIDO"
$Quick.Location=New-Object Drawing.Point(560,112)
$Quick.Size=New-Object Drawing.Size(190,24)
$Quick.ForeColor="LightSkyBlue"
$Quick.BackColor=$F.BackColor
$Quick.Checked=$false
$F.Controls.Add($Quick)

$B=New-Object Windows.Forms.Button;$B.Text="INICIAR DIAGNÓSTICO";$B.Size="210,42";$B.Location="740,25";$B.BackColor=[Drawing.Color]::FromArgb(0,120,215);$B.ForeColor="White";$F.Controls.Add($B)
$H=Label "Saúde do PC: AGUARDANDO" 31 108 "500,35" "Segoe UI,14"
$Reason=Label "O diagnóstico ainda não foi iniciado." 31 140 "650,24" "Segoe UI,9"
$Reason.ForeColor="Silver"
$HistoryIndicator=Label "Histórico: aguardando comparação com o diagnóstico anterior" 31 164 "620,22" "Segoe UI,9"
$HistoryIndicator.ForeColor="Silver"
$S=Label "Pronto para iniciar" 31 188 "500,25"
$TE=Label "Etapa: 00:00:00" 650 188 "145,25";$TT=Label "Total: 00:00:00" 815 188 "145,25"
$P=New-Object Windows.Forms.ProgressBar;$P.Location="31,216";$P.Size="850,25";$F.Controls.Add($P);$Q=Label "0%" 895 217 "55,25"

$panel=New-Object Windows.Forms.Panel;$panel.Location="31,248";$panel.Size="920,350";$panel.BackColor=$F.BackColor;$F.Controls.Add($panel)
$names=@("Sistema","Hardware","Nota do hardware","Discos e volumes","CHKDSK C: /scan","DISM RestoreHealth","SFC /scannow","DISM ScanHealth","Windows Update","Limpeza segura","Rede","Otimização C:","Inicialização","Armazenamento","Microsoft Defender","Resumo de saúde")
$cards=@{}
$cardBars=@{}
function StatusBarColor([string]$status){
 if($status -match 'FALHA|ERRO|VERMELHO'){return [Drawing.Color]::Tomato}
 if($status -match 'ALERTA|LARANJA|ATENCAO|ATENÇÃO|AMARELO|REINICIAR'){return [Drawing.Color]::Orange}
 if($status -match '^INFO$|EXECUTANDO|ANALISANDO'){return [Drawing.Color]::DeepSkyBlue}
 if($status -match '^(OK|[0-9]+[\.,][0-9]+/10)' -or $status -match 'MUITO BOM|VERDE|CONCLUIDO'){return [Drawing.Color]::LimeGreen}
 return [Drawing.Color]::FromArgb(105,115,125)
}
for($i=0;$i-lt16;$i++){
 $cp=New-Object Windows.Forms.Panel;$cp.Location=New-Object Drawing.Point((($i%4)*228),([math]::Floor($i/4)*84));$cp.Size="215,75";$cp.BackColor=[Drawing.Color]::FromArgb(31,39,49);$panel.Controls.Add($cp)
 $bar=New-Object Windows.Forms.Panel;$bar.Location="0,0";$bar.Size="5,75";$bar.BackColor=StatusBarColor "AGUARDANDO";$cp.Controls.Add($bar);$bar.BringToFront();$cardBars[$names[$i]]=$bar
 $n=New-Object Windows.Forms.Label;$n.Text=$names[$i];$n.Location="10,9";$n.Size="195,23";$n.ForeColor="White";$cp.Controls.Add($n)
 $v=New-Object Windows.Forms.Label;$v.Text="AGUARDANDO";$v.Location="10,42";$v.Size="195,23";$v.ForeColor="Silver";$v.Font="Segoe UI Semibold,9";$cp.Controls.Add($v);$cards[$names[$i]]=$v
}
$D=New-Object Windows.Forms.Button;$D.Text="DETALHES TÉCNICOS";$D.Size="205,36";$D.Location="215,715";$F.Controls.Add($D)
$R=New-Object Windows.Forms.Button;$R.Text="SALVAR RELATÓRIO";$R.Enabled=$false;$R.Size="170,36";$AdviceTitle=Label "ORIENTAÇÃO" 455 698 "120,20" "Segoe UI,9"
$AdviceTitle.ForeColor="LightSkyBlue";$AdviceTitle.Visible=$false
$Advice=Label "A orientação aparecerá ao final do diagnóstico." 455 720 "480,40" "Segoe UI,9"
$Advice.ForeColor="Silver";$Advice.Visible=$false
$R.Location="31,715";$F.Controls.Add($R)
$ModeLabel=Label "MODO:" 31 690 "50,20" "Segoe UI,8"
$ModeLabel.ForeColor="Gray"
$Mode=New-Object Windows.Forms.ComboBox;$Mode.Location="80,687";$Mode.Size="120,24";$Mode.DropDownStyle="DropDownList";[void]$Mode.Items.Add("USUÁRIO");[void]$Mode.Items.Add("TÉCNICO");$Mode.SelectedIndex=0;$F.Controls.Add($Mode)
$Pdf=New-Object Windows.Forms.Button;$Pdf.Text="RELATÓRIO PDF";$Pdf.Enabled=$false;$Pdf.Size="150,36";$Pdf.Location="425,715";$F.Controls.Add($Pdf)
$foot=Label "Windows Care 9.0 PRO FINAL 5  •  Desenvolvido por Marcelo Bertoni Galvão" 520 722 "430,25";$foot.ForeColor="Gray";$foot.Visible=$false
$DF=New-Object Windows.Forms.Form;$DF.Text="Windows Care 9.0 PRO — Central de Saúde";$DF.Size="1000,700";$DF.StartPosition="CenterParent";$DF.BackColor=$F.BackColor
$DT=New-Object Windows.Forms.TabControl;$DT.Dock="Fill";$DF.Controls.Add($DT)
$TechBoxes=@{}
$HistoryGrid=$null;$HistorySummaryLabel=$null;$HistoryDetailLabel=$null;$HistoryStatusLabel=$null;$HistoryLastLabel=$null;$HistoryEvolutionLabel=$null;$HealthPanelValues=@{};$MonitorValues=@{}
foreach($tabName in @("Painel de Saúde","Limpeza PRO","Inicialização PRO","Software Check","Monitoramento","Resumo","Hardware","Drivers","Armazenamento","Estabilidade","Sistema","Histórico","Log Completo","Atualizações","Licença","Sobre")){
 $tp=New-Object Windows.Forms.TabPage;$tp.Text=$tabName;$tp.BackColor=[Drawing.Color]::FromArgb(9,12,17)
 if($tabName -eq "Painel de Saúde"){
   $healthTitle=New-Object Windows.Forms.Label
   $healthTitle.Text="PAINEL DE SAÚDE DO PC"
   $healthTitle.Location=New-Object Drawing.Point(18,16)
   $healthTitle.Size=New-Object Drawing.Size(500,32)
   $healthTitle.Font=New-Object Drawing.Font("Segoe UI",16,[Drawing.FontStyle]::Bold)
   $healthTitle.ForeColor=[Drawing.Color]::White
   $tp.Controls.Add($healthTitle)

   $healthSub=New-Object Windows.Forms.Label
   $healthSub.Text="Resumo visual do diagnóstico atual. O painel não altera o motor de diagnóstico."
   $healthSub.Location=New-Object Drawing.Point(20,52)
   $healthSub.Size=New-Object Drawing.Size(900,25)
   $healthSub.ForeColor=[Drawing.Color]::Silver
   $tp.Controls.Add($healthSub)

   $healthGrid=New-Object Windows.Forms.TableLayoutPanel
   $healthGrid.Location=New-Object Drawing.Point(18,90)
   $healthGrid.Size=New-Object Drawing.Size(940,390)
   $healthGrid.ColumnCount=2
   $healthGrid.RowCount=5
   $healthGrid.BackColor=$tp.BackColor
   [void]$healthGrid.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,50)))
   [void]$healthGrid.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,50)))
   for($rr=0;$rr -lt 5;$rr++){[void]$healthGrid.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent,20)))}
   $tp.Controls.Add($healthGrid)

   foreach($healthName in @("Saúde Geral","Hardware","Sistema","Drivers","Memória","Estabilidade","Armazenamento","Microsoft Defender","Atualizações")){
      $card=New-Object Windows.Forms.Panel
      $card.Dock=[Windows.Forms.DockStyle]::Fill
      $card.Margin=New-Object Windows.Forms.Padding(7)
      $card.BackColor=[Drawing.Color]::FromArgb(31,39,49)

      $bar=New-Object Windows.Forms.Panel
      $bar.Dock=[Windows.Forms.DockStyle]::Left
      $bar.Width=6
      $bar.BackColor=[Drawing.Color]::DimGray
      $card.Controls.Add($bar)

      $name=New-Object Windows.Forms.Label
      $name.Text=$healthName
      $name.Location=New-Object Drawing.Point(18,14)
      $name.Size=New-Object Drawing.Size(390,23)
      $name.ForeColor=[Drawing.Color]::White
      $name.Font=New-Object Drawing.Font("Segoe UI",10)
      $card.Controls.Add($name)

      $value=New-Object Windows.Forms.Label
      $value.Text="AGUARDANDO"
      $value.Location=New-Object Drawing.Point(18,48)
      $value.Size=New-Object Drawing.Size(400,30)
      $value.ForeColor=[Drawing.Color]::Silver
      $value.Font=New-Object Drawing.Font("Segoe UI",11,[Drawing.FontStyle]::Bold)
      $card.Controls.Add($value)

      $HealthPanelValues[$healthName]=[pscustomobject]@{Value=$value;Bar=$bar}
      [void]$healthGrid.Controls.Add($card)
   }

   $healthAttention=New-Object Windows.Forms.Panel
   $healthAttention.Location=New-Object Drawing.Point(25,492)
   $healthAttention.Size=New-Object Drawing.Size(926,70)
   $healthAttention.BackColor=[Drawing.Color]::FromArgb(31,39,49)
   $tp.Controls.Add($healthAttention)
   $hat=New-Object Windows.Forms.Label;$hat.Text="O QUE REQUER ATENÇÃO AGORA";$hat.Location=New-Object Drawing.Point(16,8);$hat.Size=New-Object Drawing.Size(330,20);$hat.Font=New-Object Drawing.Font("Segoe UI",9,[Drawing.FontStyle]::Bold);$hat.ForeColor="LightSkyBlue";$healthAttention.Controls.Add($hat)
   $hav=New-Object Windows.Forms.Label;$hav.Text="Execute um diagnóstico para atualizar as prioridades.";$hav.Location=New-Object Drawing.Point(16,32);$hav.Size=New-Object Drawing.Size(880,30);$hav.ForeColor="Gainsboro";$healthAttention.Controls.Add($hav)
   $HealthPanelValues["Atenção"]=[pscustomobject]@{Value=$hav;Bar=$null}

   $healthLegend=New-Object Windows.Forms.Label
   $healthLegend.Text="Verde = OK   |   Azul = informativo   |   Laranja = atenção/alerta   |   Vermelho = falha de coleta"
   $healthLegend.Location=New-Object Drawing.Point(20,570)
   $healthLegend.Size=New-Object Drawing.Size(900,28)
   $healthLegend.ForeColor=[Drawing.Color]::Gainsboro
   $tp.Controls.Add($healthLegend)
}elseif($tabName -eq "Limpeza PRO"){
   $clTitle=New-Object Windows.Forms.Label;$clTitle.Text="LIMPEZA PRO";$clTitle.Location="18,16";$clTitle.Size="500,34";$clTitle.Font="Segoe UI,16,style=Bold";$clTitle.ForeColor="White";$tp.Controls.Add($clTitle)
   $clSub=New-Object Windows.Forms.Label;$clSub.Text="Analisa primeiro e só remove itens selecionados após sua confirmação. Downloads e arquivos pessoais não são incluídos.";$clSub.Location="20,54";$clSub.Size="920,42";$clSub.ForeColor="Silver";$tp.Controls.Add($clSub)
   $cleanupRows=@{}
   $cleanupChecks=@{}
   $cleanupNames=@("Temporários do usuário","Temporários do Windows","Relatórios de erro do Windows","Lixeira")
   $yy=112
   foreach($cn in $cleanupNames){
      $cpn=New-Object Windows.Forms.Panel;$cpn.Location=New-Object Drawing.Point(20,$yy);$cpn.Size=New-Object Drawing.Size(920,72);$cpn.BackColor=[Drawing.Color]::FromArgb(31,39,49);$tp.Controls.Add($cpn)
      $cb=New-Object Windows.Forms.CheckBox;$cb.Text=$cn;$cb.Location="18,12";$cb.Size="430,25";$cb.ForeColor="White";$cb.Checked=$true;$cpn.Controls.Add($cb)
      $cv=New-Object Windows.Forms.Label;$cv.Text="Aguardando análise";$cv.Location="470,13";$cv.Size="410,24";$cv.TextAlign="MiddleRight";$cv.ForeColor="LightSkyBlue";$cpn.Controls.Add($cv)
      $cd=New-Object Windows.Forms.Label;$cd.Text="Somente arquivos descartáveis; itens em uso são ignorados.";$cd.Location="38,40";$cd.Size="820,22";$cd.ForeColor="Silver";$cpn.Controls.Add($cd)
      $cleanupRows[$cn]=$cv;$cleanupChecks[$cn]=$cb;$yy+=82
   }
   $cleanupTotal=New-Object Windows.Forms.Label;$cleanupTotal.Text="Total recuperável: execute a análise";$cleanupTotal.Location="20,455";$cleanupTotal.Size="500,30";$cleanupTotal.Font="Segoe UI,12,style=Bold";$cleanupTotal.ForeColor="White";$tp.Controls.Add($cleanupTotal)
   $cleanupStatus=New-Object Windows.Forms.Label;$cleanupStatus.Text="Nenhuma limpeza é executada automaticamente.";$cleanupStatus.Location="20,492";$cleanupStatus.Size="900,40";$cleanupStatus.ForeColor="Khaki";$tp.Controls.Add($cleanupStatus)
   $analyzeBtn=New-Object Windows.Forms.Button;$analyzeBtn.Text="ANALISAR LIMPEZA";$analyzeBtn.Location="20,545";$analyzeBtn.Size="210,42";$analyzeBtn.BackColor=[Drawing.Color]::FromArgb(0,120,215);$analyzeBtn.ForeColor="White";$tp.Controls.Add($analyzeBtn)
   $cleanBtn=New-Object Windows.Forms.Button;$cleanBtn.Text="LIMPAR SELECIONADOS";$cleanBtn.Location="245,545";$cleanBtn.Size="230,42";$cleanBtn.BackColor=[Drawing.Color]::FromArgb(45,110,65);$cleanBtn.ForeColor="White";$cleanBtn.Enabled=$false;$tp.Controls.Add($cleanBtn)
   $script:CleanupAnalysis=$null
   $analyzeBtn.Add_Click({
      $cleanupStatus.Text="Analisando arquivos descartáveis...";$cleanupStatus.ForeColor="LightSkyBlue";$analyzeBtn.Enabled=$false;$cleanBtn.Enabled=$false;[Windows.Forms.Application]::DoEvents()
      try{
        $script:CleanupAnalysis=Get-CleanupAnalysis;$tot=0L
        foreach($cn in $cleanupNames){$b=[long]$script:CleanupAnalysis[$cn];$cleanupRows[$cn].Text=Format-CleanupBytes $b;$tot+=$b}
        $cleanupTotal.Text="Total recuperável estimado: $(Format-CleanupBytes $tot)";$cleanupStatus.Text="Análise concluída. Revise as categorias e clique em LIMPAR SELECIONADOS.";$cleanupStatus.ForeColor="LightGreen";$cleanBtn.Enabled=$true
      }catch{$cleanupStatus.Text="Falha na análise: $($_.Exception.Message)";$cleanupStatus.ForeColor="Tomato"}
      $analyzeBtn.Enabled=$true
   })
   $cleanBtn.Add_Click({
      if($null -eq $script:CleanupAnalysis){return}
      $selected=@($cleanupNames|Where-Object{$cleanupChecks[$_].Checked})
      if($selected.Count -eq 0){[Windows.Forms.MessageBox]::Show("Selecione pelo menos uma categoria.","Limpeza PRO")|Out-Null;return}
      $selTotal=0L;foreach($cn in $selected){$selTotal += [long]$script:CleanupAnalysis[$cn]}
      $msg="O Windows Care removerá somente as categorias selecionadas.`r`n`r`nEstimativa: $(Format-CleanupBytes $selTotal)`r`n`r`nArquivos em uso serão ignorados. Downloads e arquivos pessoais não serão removidos.`r`n`r`nDeseja continuar?"
      if([Windows.Forms.MessageBox]::Show($msg,"Confirmar Limpeza PRO",[Windows.Forms.MessageBoxButtons]::YesNo,[Windows.Forms.MessageBoxIcon]::Warning)-ne [Windows.Forms.DialogResult]::Yes){return}
      $cleanupStatus.Text="Executando limpeza segura...";$cleanupStatus.ForeColor="LightSkyBlue";$cleanBtn.Enabled=$false;$analyzeBtn.Enabled=$false;[Windows.Forms.Application]::DoEvents()
      try{
        foreach($cn in $selected){
          switch($cn){
            'Temporários do usuário' {Remove-CleanupContents ([IO.Path]::GetTempPath())}
            'Temporários do Windows' {Remove-CleanupContents (Join-Path $env:WINDIR 'Temp')}
            'Relatórios de erro do Windows' {Remove-CleanupContents (Join-Path $env:ProgramData 'Microsoft\Windows\WER\ReportArchive')}
            'Lixeira' {try{Clear-RecycleBin -Force -ErrorAction SilentlyContinue}catch{}}
          }
        }
        $script:CleanupAnalysis=Get-CleanupAnalysis;$remain=0L
        foreach($cn in $cleanupNames){$b=[long]$script:CleanupAnalysis[$cn];$cleanupRows[$cn].Text=Format-CleanupBytes $b;$remain+=$b}
        $cleanupTotal.Text="Restante após limpeza: $(Format-CleanupBytes $remain)";$cleanupStatus.Text="Limpeza concluída. Itens bloqueados/em uso podem permanecer.";$cleanupStatus.ForeColor="LightGreen"
      }catch{$cleanupStatus.Text="A limpeza terminou com ocorrência: $($_.Exception.Message)";$cleanupStatus.ForeColor="Orange"}
      $cleanBtn.Enabled=$true;$analyzeBtn.Enabled=$true
   })

}elseif($tabName -eq "Inicialização PRO"){
   $stTitle=New-Object Windows.Forms.Label;$stTitle.Text="INICIALIZAÇÃO PRO";$stTitle.Location="18,16";$stTitle.Size="500,34";$stTitle.Font="Segoe UI,16,style=Bold";$stTitle.ForeColor="White";$tp.Controls.Add($stTitle)
   $stSub=New-Object Windows.Forms.Label;$stSub.Text="Inventário somente leitura dos itens que iniciam com o Windows. Nesta Alpha nenhum item é desativado automaticamente.";$stSub.Location="20,54";$stSub.Size="920,42";$stSub.ForeColor="Silver";$tp.Controls.Add($stSub)
   $startupGrid=New-Object Windows.Forms.DataGridView;$startupGrid.Location="20,105";$startupGrid.Size="920,405";$startupGrid.ReadOnly=$true;$startupGrid.AllowUserToAddRows=$false;$startupGrid.AllowUserToDeleteRows=$false;$startupGrid.RowHeadersVisible=$false;$startupGrid.AutoSizeColumnsMode="Fill";$startupGrid.BackgroundColor=[Drawing.Color]::FromArgb(9,12,17);$startupGrid.ForeColor="Gainsboro";$startupGrid.GridColor=[Drawing.Color]::FromArgb(55,65,75);$startupGrid.EnableHeadersVisualStyles=$false;$startupGrid.ColumnHeadersDefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(31,39,49);$startupGrid.ColumnHeadersDefaultCellStyle.ForeColor="White";$startupGrid.DefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(18,22,28);$startupGrid.DefaultCellStyle.ForeColor="Gainsboro";$startupGrid.DefaultCellStyle.SelectionBackColor=[Drawing.Color]::FromArgb(40,70,95);$startupGrid.DefaultCellStyle.SelectionForeColor="White";$tp.Controls.Add($startupGrid)
   [void]$startupGrid.Columns.Add("Nome","Nome");[void]$startupGrid.Columns.Add("Origem","Origem");[void]$startupGrid.Columns.Add("Status","Status");[void]$startupGrid.Columns.Add("Comando","Comando / caminho")
   $startupStatus=New-Object Windows.Forms.Label;$startupStatus.Text="Clique em ANALISAR INICIALIZAÇÃO.";$startupStatus.Location="20,520";$startupStatus.Size="700,30";$startupStatus.ForeColor="Khaki";$tp.Controls.Add($startupStatus)
   $startupBtn=New-Object Windows.Forms.Button;$startupBtn.Text="ANALISAR INICIALIZAÇÃO";$startupBtn.Location="20,558";$startupBtn.Size="230,42";$startupBtn.BackColor=[Drawing.Color]::FromArgb(0,120,215);$startupBtn.ForeColor="White";$tp.Controls.Add($startupBtn)
   $startupBtn.Add_Click({
      $startupBtn.Enabled=$false;$startupStatus.Text="Analisando itens de inicialização...";$startupStatus.ForeColor="LightSkyBlue";[Windows.Forms.Application]::DoEvents()
      try{$items=@(Get-StartupInventory);$startupGrid.Rows.Clear();foreach($it in $items){[void]$startupGrid.Rows.Add($it.Nome,$it.Origem,$it.Status,$it.Comando)};$startupStatus.Text=("{0} item(ns) de inicialização encontrado(s). Somente leitura; nenhuma alteração foi feita." -f $items.Count);$startupStatus.ForeColor="LightGreen"}catch{$startupStatus.Text="Falha na coleta: $($_.Exception.Message)";$startupStatus.ForeColor="Tomato"}finally{$startupBtn.Enabled=$true}
   })
}elseif($tabName -eq "Software Check"){
   $swTitle=New-Object Windows.Forms.Label;$swTitle.Text="SOFTWARE CHECK";$swTitle.Location="18,16";$swTitle.Size="500,34";$swTitle.Font="Segoe UI,16,style=Bold";$swTitle.ForeColor="White";$tp.Controls.Add($swTitle)
   $swSub=New-Object Windows.Forms.Label;$swSub.Text="Inventário dos programas instalados e verificação opcional de atualizações pelo winget. Nenhuma atualização é instalada automaticamente.";$swSub.Location="20,54";$swSub.Size="920,42";$swSub.ForeColor="Silver";$tp.Controls.Add($swSub)
   $softwareGrid=New-Object Windows.Forms.DataGridView;$softwareGrid.Location="20,105";$softwareGrid.Size="920,385";$softwareGrid.ReadOnly=$true;$softwareGrid.AllowUserToAddRows=$false;$softwareGrid.AllowUserToDeleteRows=$false;$softwareGrid.RowHeadersVisible=$false;$softwareGrid.AutoSizeColumnsMode="Fill";$softwareGrid.BackgroundColor=[Drawing.Color]::FromArgb(9,12,17);$softwareGrid.ForeColor="Gainsboro";$softwareGrid.GridColor=[Drawing.Color]::FromArgb(55,65,75);$softwareGrid.EnableHeadersVisualStyles=$false;$softwareGrid.ColumnHeadersDefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(31,39,49);$softwareGrid.ColumnHeadersDefaultCellStyle.ForeColor="White";$softwareGrid.DefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(18,22,28);$softwareGrid.DefaultCellStyle.ForeColor="Gainsboro";$softwareGrid.DefaultCellStyle.SelectionBackColor=[Drawing.Color]::FromArgb(40,70,95);$softwareGrid.DefaultCellStyle.SelectionForeColor="White";$tp.Controls.Add($softwareGrid)
   [void]$softwareGrid.Columns.Add("Programa","Programa");[void]$softwareGrid.Columns.Add("Versao","Versão instalada");[void]$softwareGrid.Columns.Add("Fabricante","Fabricante")
   $softwareStatus=New-Object Windows.Forms.Label;$softwareStatus.Text="Clique em INVENTARIAR PROGRAMAS.";$softwareStatus.Location="20,500";$softwareStatus.Size="900,42";$softwareStatus.ForeColor="Khaki";$tp.Controls.Add($softwareStatus)
   $softwareBtn=New-Object Windows.Forms.Button;$softwareBtn.Text="INVENTARIAR PROGRAMAS";$softwareBtn.Location="20,550";$softwareBtn.Size="220,42";$softwareBtn.BackColor=[Drawing.Color]::FromArgb(0,120,215);$softwareBtn.ForeColor="White";$tp.Controls.Add($softwareBtn)
   $wingetBtn=New-Object Windows.Forms.Button;$wingetBtn.Text="VERIFICAR ATUALIZAÇÕES";$wingetBtn.Location="255,550";$wingetBtn.Size="230,42";$wingetBtn.BackColor=[Drawing.Color]::FromArgb(45,90,125);$wingetBtn.ForeColor="White";$tp.Controls.Add($wingetBtn)
   $softwareBtn.Add_Click({
      $softwareBtn.Enabled=$false;$softwareStatus.Text="Inventariando programas instalados...";$softwareStatus.ForeColor="LightSkyBlue";[Windows.Forms.Application]::DoEvents()
      try{$apps=@(Get-InstalledSoftwareInventory);$softwareGrid.Rows.Clear();foreach($a in $apps){[void]$softwareGrid.Rows.Add($a.Programa,$a.Versao,$a.Fabricante)};$softwareStatus.Text=("{0} programa(s) identificado(s). Nenhuma alteração foi feita." -f $apps.Count);$softwareStatus.ForeColor="LightGreen"}catch{$softwareStatus.Text="Falha na coleta: $($_.Exception.Message)";$softwareStatus.ForeColor="Tomato"}finally{$softwareBtn.Enabled=$true}
   })
   $wingetBtn.Add_Click({
      $winget=Get-Command winget.exe -ErrorAction SilentlyContinue
      if(-not $winget){[Windows.Forms.MessageBox]::Show("O winget não está disponível neste Windows. O inventário local continua funcionando normalmente.","Software Check")|Out-Null;return}
      $softwareStatus.Text="Consultando atualizações disponíveis pelo winget...";$softwareStatus.ForeColor="LightSkyBlue";$wingetBtn.Enabled=$false;[Windows.Forms.Application]::DoEvents()
      try{
         $lines=@(& $winget.Source upgrade --accept-source-agreements 2>&1 | ForEach-Object { [string]$_ })
         $sep=-1
         for($i=0;$i -lt $lines.Count;$i++){if($lines[$i] -match '^[-]{5,}'){ $sep=$i; break }}
         $updates=@()
         if($sep -ge 1){
            for($j=$sep+1;$j -lt $lines.Count;$j++){
               $ln=[string]$lines[$j]
               if([string]::IsNullOrWhiteSpace($ln)){continue}
               if($ln -match '^\s*\d+\s+(atualiza|upgrade|package|pacote)'){continue}
               # WinGet separates Nome from ID with 2+ spaces. The remaining fields contain no spaces.
               if($ln -match '^\s*(?<Nome>.+?)\s{2,}(?<Id>\S+)\s+(?<Instalada>\S+)\s+(?<Disponivel>\S+)\s+(?<Origem>\S+)\s*$'){
                  $nome=[string]$Matches['Nome']
                  $inst=[string]$Matches['Instalada']
                  $nova=[string]$Matches['Disponivel']
                  $orig=[string]$Matches['Origem']
                  if($nome -and $inst -and $nova){
                     $updates += [pscustomobject]@{Programa=$nome.Trim();Instalada=$inst.Trim();Disponivel=$nova.Trim();Origem=$orig.Trim()}
                  }
               }
            }
         }
         $viewer=New-Object Windows.Forms.Form;$viewer.Text="Software Check — Atualizações disponíveis";$viewer.Size="980,600";$viewer.StartPosition="CenterParent";$viewer.BackColor=[Drawing.Color]::FromArgb(18,22,28)
         $vg=New-Object Windows.Forms.DataGridView;$vg.Location="15,15";$vg.Size="935,485";$vg.ReadOnly=$true;$vg.AllowUserToAddRows=$false;$vg.AllowUserToDeleteRows=$false;$vg.RowHeadersVisible=$false;$vg.AutoSizeColumnsMode="Fill";$vg.BackgroundColor=[Drawing.Color]::FromArgb(9,12,17);$vg.ForeColor="Gainsboro";$vg.GridColor=[Drawing.Color]::FromArgb(55,65,75);$vg.EnableHeadersVisualStyles=$false;$vg.ColumnHeadersDefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(31,39,49);$vg.ColumnHeadersDefaultCellStyle.ForeColor="White";$vg.DefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(18,22,28);$vg.DefaultCellStyle.ForeColor="Gainsboro";$vg.DefaultCellStyle.SelectionBackColor=[Drawing.Color]::FromArgb(40,70,95);$vg.DefaultCellStyle.SelectionForeColor="White"
         [void]$vg.Columns.Add("Programa","Programa");[void]$vg.Columns.Add("Instalada","Versão instalada");[void]$vg.Columns.Add("Disponivel","Nova versão");[void]$vg.Columns.Add("Origem","Origem")
         foreach($u in $updates){[void]$vg.Rows.Add($u.Programa,$u.Instalada,$u.Disponivel,$u.Origem)};$viewer.Controls.Add($vg)
         $vl=New-Object Windows.Forms.Label;$vl.Location="15,515";$vl.Size="930,28";$vl.ForeColor="LightGreen";$vl.Text=("{0} atualização(ões) identificada(s). Somente consulta; nada foi instalado." -f $updates.Count);$viewer.Controls.Add($vl)
         $softwareStatus.Text=("Consulta concluída: {0} atualização(ões) identificada(s). Nenhuma foi instalada." -f $updates.Count);$softwareStatus.ForeColor="LightGreen";[void]$viewer.ShowDialog($DF)
      }catch{$softwareStatus.Text="Falha na consulta: $($_.Exception.Message)";$softwareStatus.ForeColor="Tomato"}finally{$wingetBtn.Enabled=$true}
   })
}elseif($tabName -eq "Drivers"){
   $drTitle=New-Object Windows.Forms.Label;$drTitle.Text="DRIVERS PRO";$drTitle.Location="18,16";$drTitle.Size="500,34";$drTitle.Font="Segoe UI,16,style=Bold";$drTitle.ForeColor="White";$tp.Controls.Add($drTitle)
   $drSub=New-Object Windows.Forms.Label;$drSub.Text="Inventário classificado e somente leitura. Data antiga, sozinha, não significa driver com problema.";$drSub.Location="20,54";$drSub.Size="920,42";$drSub.ForeColor="Silver";$tp.Controls.Add($drSub)
   $driverGrid=New-Object Windows.Forms.DataGridView;$driverGrid.Location="20,105";$driverGrid.Size="920,405";$driverGrid.ReadOnly=$true;$driverGrid.AllowUserToAddRows=$false;$driverGrid.AllowUserToDeleteRows=$false;$driverGrid.RowHeadersVisible=$false;$driverGrid.AutoSizeColumnsMode="Fill";$driverGrid.BackgroundColor=[Drawing.Color]::FromArgb(9,12,17);$driverGrid.ForeColor="Gainsboro";$driverGrid.GridColor=[Drawing.Color]::FromArgb(55,65,75);$driverGrid.EnableHeadersVisualStyles=$false;$driverGrid.ColumnHeadersDefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(31,39,49);$driverGrid.ColumnHeadersDefaultCellStyle.ForeColor="White";$driverGrid.DefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(18,22,28);$driverGrid.DefaultCellStyle.ForeColor="Gainsboro";$driverGrid.DefaultCellStyle.SelectionBackColor=[Drawing.Color]::FromArgb(40,70,95);$driverGrid.DefaultCellStyle.SelectionForeColor="White";$tp.Controls.Add($driverGrid)
   [void]$driverGrid.Columns.Add("Categoria","Categoria");[void]$driverGrid.Columns.Add("Dispositivo","Dispositivo");[void]$driverGrid.Columns.Add("Fabricante","Fabricante");[void]$driverGrid.Columns.Add("Versao","Versão");[void]$driverGrid.Columns.Add("Data","Data");[void]$driverGrid.Columns.Add("Assinado","Assinado");[void]$driverGrid.Columns.Add("Estado","Estado")
   $driverStatus=New-Object Windows.Forms.Label;$driverStatus.Text="Clique em ANALISAR DRIVERS.";$driverStatus.Location="20,520";$driverStatus.Size="900,30";$driverStatus.ForeColor="Khaki";$tp.Controls.Add($driverStatus)
   $driverBtn=New-Object Windows.Forms.Button;$driverBtn.Text="ANALISAR DRIVERS";$driverBtn.Location="20,558";$driverBtn.Size="220,42";$driverBtn.BackColor=[Drawing.Color]::FromArgb(0,120,215);$driverBtn.ForeColor="White";$tp.Controls.Add($driverBtn)
   $driverBtn.Add_Click({
      $driverBtn.Enabled=$false;$driverStatus.Text="Coletando e classificando drivers...";$driverStatus.ForeColor="LightSkyBlue";[Windows.Forms.Application]::DoEvents()
      try{
         $driverGrid.Rows.Clear()
         $all=@(Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop | Where-Object {$_.DeviceName} | Sort-Object DeviceName)
         $pnp=@{};Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | ForEach-Object {if($_.PNPDeviceID){$pnp[[string]$_.PNPDeviceID]=$_.ConfigManagerErrorCode}}
         $unsigned=0;$attention=0;$unknown=0
         foreach($d in $all){
            $n=[string]$d.DeviceName;$m=[string]$d.Manufacturer;$low=($n+' '+$m).ToLowerInvariant();$cat="Outros"
            if($low -match 'radeon|display|graphics|video|nvidia|geforce|intel.*graphics'){$cat="Vídeo"}
            elseif($low -match 'ethernet|wi-fi|wifi|wireless|network|bluetooth|realtek.*gbe'){$cat="Rede"}
            elseif($low -match 'audio|sound|high definition|endpoint'){$cat="Áudio"}
            elseif($low -match 'nvme|sata|storage|scsi|disk|ahci|raid'){$cat="Armazenamento"}
            elseif($low -match 'usb|universal serial'){$cat="USB"}
            elseif($low -match 'acpi|chipset|pci|system|processor|smbus|controller'){$cat="Sistema/Chipset"}
            $date="N/D";if($d.DriverDate){try{if($d.DriverDate -is [datetime]){$date=$d.DriverDate.ToString('dd/MM/yyyy')}else{$date=([Management.ManagementDateTimeConverter]::ToDateTime([string]$d.DriverDate)).ToString('dd/MM/yyyy')}}catch{$date="N/D"}}
            $signed="N/D";if($null -ne $d.IsSigned){if([bool]$d.IsSigned){$signed="SIM"}else{$signed="NÃO";$unsigned++}}
            $estado="OK";$code=$null;if($d.DeviceID -and $pnp.ContainsKey([string]$d.DeviceID)){$code=$pnp[[string]$d.DeviceID]}
            if($null -ne $code -and [int]$code -ne 0){$estado="VERIFICAR (código $code)";$attention++}elseif($signed -eq "NÃO"){$estado="VERIFICAR ASSINATURA";$attention++}elseif($signed -eq "N/D"){$estado="INFO INDISPONÍVEL";$unknown++}
            $ri=$driverGrid.Rows.Add($cat,$n,$m,[string]$d.DriverVersion,$date,$signed,$estado)
            if($estado -like 'VERIFICAR*'){$driverGrid.Rows[$ri].DefaultCellStyle.ForeColor="Orange"}elseif($estado -eq 'INFO INDISPONÍVEL'){$driverGrid.Rows[$ri].DefaultCellStyle.ForeColor="DeepSkyBlue"}
         }
         if($attention -gt 0){$driverStatus.Text=("{0} driver(s) | {1} item(ns) para verificar | {2} informação(ões) indisponível(is). Nenhuma alteração feita." -f $all.Count,$attention,$unknown);$driverStatus.ForeColor="Orange"}else{$driverStatus.Text=("{0} driver(s) | nenhum problema reportado pelo Windows nos itens coletados. Somente diagnóstico." -f $all.Count);$driverStatus.ForeColor="LightGreen"}
      }catch{$driverStatus.Text="FALHA NA COLETA: $($_.Exception.Message)";$driverStatus.ForeColor="Tomato"}finally{$driverBtn.Enabled=$true}
   })
}elseif($tabName -eq "Monitoramento"){
   $mt=New-Object Windows.Forms.Label;$mt.Text="PAINEL DE MONITORAMENTO";$mt.Location=New-Object Drawing.Point(18,14);$mt.Size=New-Object Drawing.Size(600,32);$mt.Font=New-Object Drawing.Font("Segoe UI",16,[Drawing.FontStyle]::Bold);$mt.ForeColor="White";$tp.Controls.Add($mt)
   $ms=New-Object Windows.Forms.Label;$ms.Text="Acompanhamento do último diagnóstico e da evolução registrada. Somente leitura.";$ms.Location=New-Object Drawing.Point(20,50);$ms.Size=New-Object Drawing.Size(900,24);$ms.ForeColor="Silver";$tp.Controls.Add($ms)
   $mg=New-Object Windows.Forms.TableLayoutPanel;$mg.Location=New-Object Drawing.Point(18,86);$mg.Size=New-Object Drawing.Size(940,400);$mg.ColumnCount=2;$mg.RowCount=5;$mg.BackColor=$tp.BackColor
   [void]$mg.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,50)));[void]$mg.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle([Windows.Forms.SizeType]::Percent,50)))
   for($mr=0;$mr -lt 5;$mr++){[void]$mg.RowStyles.Add((New-Object Windows.Forms.RowStyle([Windows.Forms.SizeType]::Percent,25)))}
   $tp.Controls.Add($mg)
   foreach($mn in @("Último diagnóstico","Evolução","Armazenamento","Temperaturas","Estabilidade","Memória","Segurança","Última ocorrência","Espaço C:","Tendência histórica")){
      $mc=New-Object Windows.Forms.Panel;$mc.Dock="Fill";$mc.Margin=New-Object Windows.Forms.Padding(7);$mc.BackColor=[Drawing.Color]::FromArgb(31,39,49)
      $mb=New-Object Windows.Forms.Panel;$mb.Dock="Left";$mb.Width=6;$mb.BackColor="DimGray";$mc.Controls.Add($mb)
      $ml=New-Object Windows.Forms.Label;$ml.Text=$mn;$ml.Location=New-Object Drawing.Point(18,10);$ml.Size=New-Object Drawing.Size(410,20);$ml.ForeColor="White";$mc.Controls.Add($ml)
      $mv=New-Object Windows.Forms.Label;$mv.Text="AGUARDANDO";$mv.Location=New-Object Drawing.Point(18,36);$mv.Size=New-Object Drawing.Size(420,34);$mv.ForeColor="Silver";$mv.Font=New-Object Drawing.Font("Segoe UI",9,[Drawing.FontStyle]::Bold);$mc.Controls.Add($mv)
      $MonitorValues[$mn]=[pscustomobject]@{Value=$mv;Bar=$mb};[void]$mg.Controls.Add($mc)
   }
   $att=New-Object Windows.Forms.Panel;$att.Location=New-Object Drawing.Point(25,500);$att.Size=New-Object Drawing.Size(926,105);$att.BackColor=[Drawing.Color]::FromArgb(31,39,49);$tp.Controls.Add($att)
   $at=New-Object Windows.Forms.Label;$at.Text="O QUE REQUER ATENÇÃO AGORA";$at.Location=New-Object Drawing.Point(16,12);$at.Size=New-Object Drawing.Size(400,22);$at.Font=New-Object Drawing.Font("Segoe UI",10,[Drawing.FontStyle]::Bold);$at.ForeColor="LightSkyBlue";$att.Controls.Add($at)
   $av=New-Object Windows.Forms.Label;$av.Text="Execute um diagnóstico para atualizar o acompanhamento.";$av.Location=New-Object Drawing.Point(16,38);$av.Size=New-Object Drawing.Size(880,52);$av.ForeColor="Gainsboro";$att.Controls.Add($av);$MonitorValues["Atenção"]=[pscustomobject]@{Value=$av;Bar=$null}
}elseif($tabName -eq "Histórico"){
   $HistoryStatusLabel=New-Object Windows.Forms.Label;$HistoryStatusLabel.Location="12,10";$HistoryStatusLabel.Size="180,28";$HistoryStatusLabel.Font="Segoe UI Semibold,12";$HistoryStatusLabel.Text="SEM HISTÓRICO";$tp.Controls.Add($HistoryStatusLabel)
   $HistorySummaryLabel=New-Object Windows.Forms.Label;$HistorySummaryLabel.Location="200,12";$HistorySummaryLabel.Size="752,24";$HistorySummaryLabel.ForeColor="LightSkyBlue";$HistorySummaryLabel.Font="Segoe UI Semibold,10";$tp.Controls.Add($HistorySummaryLabel)
   $HistoryDetailLabel=New-Object Windows.Forms.Label;$HistoryDetailLabel.Location="12,42";$HistoryDetailLabel.Size="940,34";$HistoryDetailLabel.ForeColor="Gainsboro";$tp.Controls.Add($HistoryDetailLabel)
   $HistoryLastLabel=New-Object Windows.Forms.Label;$HistoryLastLabel.Location="12,76";$HistoryLastLabel.Size="940,24";$HistoryLastLabel.ForeColor="Khaki";$HistoryLastLabel.Font="Segoe UI,9";$tp.Controls.Add($HistoryLastLabel)
   $HistoryEvolutionLabel=New-Object Windows.Forms.Label;$HistoryEvolutionLabel.Location="12,102";$HistoryEvolutionLabel.Size="940,40";$HistoryEvolutionLabel.ForeColor="LightGreen";$HistoryEvolutionLabel.Font="Segoe UI,9";$tp.Controls.Add($HistoryEvolutionLabel)
   $HistoryGrid=New-Object Windows.Forms.DataGridView;$HistoryGrid.Location="12,150";$HistoryGrid.Size="945,458";$HistoryGrid.ReadOnly=$true;$HistoryGrid.AllowUserToAddRows=$false;$HistoryGrid.AllowUserToDeleteRows=$false;$HistoryGrid.AllowUserToResizeRows=$false;$HistoryGrid.RowHeadersVisible=$false;$HistoryGrid.AutoSizeColumnsMode="Fill";$HistoryGrid.BackgroundColor=[Drawing.Color]::FromArgb(9,12,17);$HistoryGrid.ForeColor="Gainsboro";$HistoryGrid.GridColor=[Drawing.Color]::FromArgb(55,65,75);$HistoryGrid.ColumnHeadersDefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(31,39,49);$HistoryGrid.ColumnHeadersDefaultCellStyle.ForeColor="White";$HistoryGrid.EnableHeadersVisualStyles=$false;$HistoryGrid.DefaultCellStyle.BackColor=[Drawing.Color]::FromArgb(18,22,28);$HistoryGrid.DefaultCellStyle.ForeColor="Gainsboro";$HistoryGrid.DefaultCellStyle.SelectionBackColor=[Drawing.Color]::FromArgb(40,70,95);$HistoryGrid.DefaultCellStyle.SelectionForeColor="White";$HistoryGrid.Font="Segoe UI,9"
   foreach($col in @("Data","Saúde","Modo","Nota","ID 7","Novos","ID 153","ID 129","Dispositivo")){[void]$HistoryGrid.Columns.Add(($col -replace ' ',''),$col)}
   $tp.Controls.Add($HistoryGrid)
 }elseif($tabName -eq "Atualizações"){
   $upTitle=New-Object Windows.Forms.Label;$upTitle.Text="ATUALIZAÇÕES DO WINDOWS CARE";$upTitle.Location="28,28";$upTitle.Size="760,38";$upTitle.Font="Segoe UI,18,style=Bold";$upTitle.ForeColor="White";$tp.Controls.Add($upTitle)
   $upSub=New-Object Windows.Forms.Label;$upSub.Text="FINAL: atualização controlada com backup, validação e rollback. Instalação somente com confirmação do usuário.";$upSub.Location="30,72";$upSub.Size="880,28";$upSub.ForeColor="Silver";$tp.Controls.Add($upSub)
   $curLab=New-Object Windows.Forms.Label;$curLab.Text="VERSÃO INSTALADA";$curLab.Location="30,125";$curLab.Size="220,24";$curLab.ForeColor="LightSkyBlue";$tp.Controls.Add($curLab)
   $curVal=New-Object Windows.Forms.Label;$curVal.Text="9.0 PRO FINAL 5";$curVal.Location="30,153";$curVal.Size="350,32";$curVal.Font="Segoe UI,14,style=Bold";$curVal.ForeColor="White";$tp.Controls.Add($curVal)
   $avLab=New-Object Windows.Forms.Label;$avLab.Text="VERSÃO DISPONÍVEL";$avLab.Location="430,125";$avLab.Size="220,24";$avLab.ForeColor="LightSkyBlue";$tp.Controls.Add($avLab)
   $avVal=New-Object Windows.Forms.Label;$avVal.Text="—";$avVal.Location="430,153";$avVal.Size="350,32";$avVal.Font="Segoe UI,14,style=Bold";$avVal.ForeColor="White";$tp.Controls.Add($avVal)
   $upStatus=New-Object Windows.Forms.Label;$upStatus.Text="AINDA NÃO VERIFICADO";$upStatus.Location="30,215";$upStatus.Size="650,36";$upStatus.Font="Segoe UI,15,style=Bold";$upStatus.ForeColor="LightSkyBlue";$tp.Controls.Add($upStatus)
   $upNotes=New-Object Windows.Forms.Label;$upNotes.Text="Clique em VERIFICAR ATUALIZAÇÕES.";$upNotes.Location="30,260";$upNotes.Size="850,82";$upNotes.ForeColor="Gainsboro";$tp.Controls.Add($upNotes)
   $upBtn=New-Object Windows.Forms.Button;$upBtn.Text="VERIFICAR ATUALIZAÇÕES";$upBtn.Location="30,360";$upBtn.Size="230,42";$upBtn.BackColor=[Drawing.Color]::FromArgb(10,125,210);$upBtn.ForeColor="White";$upBtn.FlatStyle="Flat";$tp.Controls.Add($upBtn)
   $dlBtn=New-Object Windows.Forms.Button;$dlBtn.Text="BAIXAR ATUALIZAÇÃO";$dlBtn.Location="280,360";$dlBtn.Size="230,42";$dlBtn.BackColor=[Drawing.Color]::FromArgb(55,65,75);$dlBtn.ForeColor="White";$dlBtn.FlatStyle="Flat";$dlBtn.Enabled=$false;$tp.Controls.Add($dlBtn)
   $dlStatus=New-Object Windows.Forms.Label;$dlStatus.Text="Download bloqueado até existir URL e SHA-256 válidos no manifesto.";$dlStatus.Location="30,415";$dlStatus.Size="850,52";$dlStatus.ForeColor="Silver";$tp.Controls.Add($dlStatus)
   $installBtn=New-Object Windows.Forms.Button;$installBtn.Text="INSTALAR ATUALIZAÇÃO";$installBtn.Location="530,360";$installBtn.Size="230,42";$installBtn.BackColor=[Drawing.Color]::FromArgb(55,65,75);$installBtn.ForeColor="White";$installBtn.FlatStyle="Flat";$installBtn.Enabled=$false;$tp.Controls.Add($installBtn)
   $script:WCValidatedUpdate=$null
   $upInfo=New-Object Windows.Forms.Label;$upInfo.Location="30,485";$upInfo.Size="850,105";$upInfo.ForeColor="Silver";$upInfo.Text="O Windows Care baixa somente quando há atualização, URL HTTPS e SHA-256 válido.`r`nO arquivo é salvo em Downloads\\WindowsCareUpdates e só é aceito se o SHA-256 for idêntico ao manifesto.`r`nNenhum arquivo é executado, instalado ou substituído automaticamente.";$tp.Controls.Add($upInfo)
   $script:WCUpdateManifest=$null
   $upBtn.Add_Click({
      $dlBtn.Enabled=$false;$installBtn.Enabled=$false;$script:WCValidatedUpdate=$null;$script:WCUpdateManifest=$null
      try{
         $manifestUrl="https://raw.githubusercontent.com/mbgalvao/windows-care-updates/refs/heads/main/update.json?t=$([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())"
         [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
         $json=Invoke-WebRequest -Uri $manifestUrl -UseBasicParsing -TimeoutSec 8 -Headers @{"Cache-Control"="no-cache"} -ErrorAction Stop
         if([string]::IsNullOrWhiteSpace([string]$json.Content)){throw "O manifesto online retornou conteúdo vazio."}
         $m=([string]$json.Content) | ConvertFrom-Json -ErrorAction Stop
         if([string]::IsNullOrWhiteSpace([string]$m.version)){throw "Manifesto online inválido: campo version ausente."}
         if([string]::IsNullOrWhiteSpace([string]$m.displayVersion)){throw "Manifesto online inválido: campo displayVersion ausente."}
         $avVal.Text=[string]$m.displayVersion;$upNotes.Text=[string]$m.notes
         $current=[version]"9.0.0.9";$available=[version]([string]$m.version)
         if($available -gt $current){
            $upStatus.Text="ATUALIZAÇÃO DISPONÍVEL";$upStatus.ForeColor="Orange";$script:WCUpdateManifest=$m
            $url=[string]$m.downloadUrl;$hash=([string]$m.sha256).Trim().ToUpperInvariant()
            $uri=$null;$httpsOk=[Uri]::TryCreate($url,[UriKind]::Absolute,[ref]$uri) -and $uri.Scheme -eq "https"
            $hashOk=$hash -match '^[A-F0-9]{64}$'
            if($httpsOk -and $hashOk){$dlBtn.Enabled=$true;$dlBtn.BackColor=[Drawing.Color]::FromArgb(10,125,210);$dlStatus.Text="Pacote disponível. O SHA-256 será verificado após o download.";$dlStatus.ForeColor="LightSkyBlue"}
            else{$dlStatus.Text="Atualização detectada, mas download ainda não liberado: preencha downloadUrl HTTPS e sha256 válido no manifesto.";$dlStatus.ForeColor="Khaki"}
         }else{$upStatus.Text="ATUALIZADO";$upStatus.ForeColor="LightGreen";$dlStatus.Text="Nenhum download necessário.";$dlStatus.ForeColor="LightGreen"}
      }catch{$upStatus.Text="FALHA NA CONSULTA";$upStatus.ForeColor="Tomato";$upNotes.Text=$_.Exception.Message;$dlStatus.Text="Download indisponível enquanto a consulta falhar.";$dlStatus.ForeColor="Tomato"}
   })
   $dlBtn.Add_Click({
      try{
         $m=$script:WCUpdateManifest;if($null -eq $m){throw "Verifique as atualizações novamente antes de baixar."}
         $url=[string]$m.downloadUrl;$expected=([string]$m.sha256).Trim().ToUpperInvariant()
         $uri=$null;if(-not [Uri]::TryCreate($url,[UriKind]::Absolute,[ref]$uri) -or $uri.Scheme -ne "https"){throw "URL de download inválida ou não HTTPS."}
         if($expected -notmatch '^[A-F0-9]{64}$'){throw "SHA-256 do manifesto inválido."}
         $dir=Join-Path $env:USERPROFILE "Downloads\WindowsCareUpdates";if(-not(Test-Path $dir)){New-Item -ItemType Directory -Path $dir -Force|Out-Null}
         $name=[IO.Path]::GetFileName($uri.AbsolutePath);if([string]::IsNullOrWhiteSpace($name)){$name="Windows_Care_Update.zip"}
         $dest=Join-Path $dir $name;$tmp=$dest+".part";if(Test-Path $tmp){Remove-Item $tmp -Force -ErrorAction SilentlyContinue}
         $dlStatus.Text="Baixando atualização...";$dlStatus.ForeColor="LightSkyBlue";[Windows.Forms.Application]::DoEvents()
         Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing -TimeoutSec 120 -ErrorAction Stop
         $actual=(Get-FileHash -Path $tmp -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
         if($actual -ne $expected){Remove-Item $tmp -Force -ErrorAction SilentlyContinue;throw "SHA-256 diferente do manifesto. O arquivo foi rejeitado e removido."}
         Move-Item -Path $tmp -Destination $dest -Force
         $script:WCValidatedUpdate=$dest;$installBtn.Enabled=$true;$installBtn.BackColor=[Drawing.Color]::FromArgb(10,125,210)
         $dlStatus.Text="DOWNLOAD VALIDADO — SHA-256 CONFERE. Pronto para instalação controlada.";$dlStatus.ForeColor="LightGreen"
         [Windows.Forms.MessageBox]::Show("Download concluído e validado por SHA-256.`r`n`r`n$dest`r`n`r`nO Windows Care NÃO executará nem instalará o arquivo automaticamente.","Windows Care 9.0 PRO",0,64)|Out-Null
      }catch{$dlStatus.Text="FALHA NO DOWNLOAD — "+$_.Exception.Message;$dlStatus.ForeColor="Tomato"}
   })
   $installBtn.Add_Click({
      try{
         $pkg=$script:WCValidatedUpdate
         if([string]::IsNullOrWhiteSpace([string]$pkg) -or -not(Test-Path $pkg)){throw "Pacote validado não localizado. Baixe a atualização novamente."}
         $answer=[Windows.Forms.MessageBox]::Show("O pacote foi validado por SHA-256.`r`n`r`nDeseja instalar a atualização agora?`r`n`r`nO Windows Care criará um backup da instalação atual. Se a atualização falhar, o Updater tentará restaurar esse backup. A licença local em LocalAppData não será substituída.","Windows Care 9.0 PRO — Confirmar atualização",4,48)
         if($answer -ne [Windows.Forms.DialogResult]::Yes){$dlStatus.Text="Instalação cancelada pelo usuário. O pacote validado foi mantido.";$dlStatus.ForeColor="Khaki";return}
         $stage=Join-Path $env:LOCALAPPDATA "WindowsCare\UpdateStaging"
         if(Test-Path $stage){Remove-Item $stage -Recurse -Force -ErrorAction Stop}
         New-Item -ItemType Directory -Path $stage -Force|Out-Null
         Expand-Archive -LiteralPath $pkg -DestinationPath $stage -Force -ErrorAction Stop
         $payload=Join-Path $stage "payload"
         $marker=Join-Path $payload "WINDOWS_CARE_UPDATE_PAYLOAD.txt"
         if(-not(Test-Path $marker)){throw "Pacote sem marcador oficial de atualização. Instalação recusada por segurança."}
         $updaterSource=Join-Path $PSScriptRoot "WindowsCareUpdater_FINAL.ps1"
         if(-not(Test-Path $updaterSource)){throw "Atualizador do Windows Care não localizado na instalação atual."}
         $updaterTemp=Join-Path $env:TEMP ("WindowsCareUpdater_FINAL_"+[Guid]::NewGuid().ToString("N")+".ps1")
         Copy-Item $updaterSource $updaterTemp -Force
         $installDir=$PSScriptRoot
         $launcher=Join-Path $installDir "INICIAR_WINDOWS_CARE_9.0_PRO_FINAL.bat"
         $qUpdater='"'+$updaterTemp+'"'
         $qInstall='"'+$installDir+'"'
         $qPayload='"'+$payload+'"'
         $qLauncher='"'+$launcher+'"'
         $args=@('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',$qUpdater,'-InstallDir',$qInstall,'-PayloadDir',$qPayload,'-Launcher',$qLauncher,'-ParentPid',[string]$PID)
         Start-Process -FilePath "powershell.exe" -ArgumentList $args -WindowStyle Normal -ErrorAction Stop
         $dlStatus.Text="ATUALIZADOR INICIADO — o Windows Care será fechado para concluir a atualização.";$dlStatus.ForeColor="LightGreen"
         [Windows.Forms.MessageBox]::Show("O atualizador separado foi iniciado.`r`n`r`nO Windows Care será fechado. O Updater fará backup, substituirá os arquivos do payload e tentará rollback automático se ocorrer falha.","Windows Care 9.0 PRO",0,64)|Out-Null
         if ($DF -and -not $DF.IsDisposed) {
            $DF.Close()
         }
         if ($F -and -not $F.IsDisposed) {
            $F.Close()
         }
      }catch{$dlStatus.Text="INSTALAÇÃO BLOQUEADA — "+$_.Exception.Message;$dlStatus.ForeColor="Tomato"}
   })
 }elseif($tabName -eq "Licença"){
   function Get-WCInstallId {
      try{$uuid=(Get-CimInstance Win32_ComputerSystemProduct -ErrorAction Stop).UUID}catch{$uuid=$env:COMPUTERNAME}
      $raw=([string]$uuid).Trim().ToUpperInvariant()
      $sha=[Security.Cryptography.SHA256]::Create();try{$b=$sha.ComputeHash([Text.Encoding]::UTF8.GetBytes("WC9|"+$raw));$hex=([BitConverter]::ToString($b)).Replace("-","");return ($hex.Substring(0,16) -replace '(.{4})(?!$)','$1-')}finally{$sha.Dispose()}
   }
   function Get-WCLicensePath { $d=Join-Path $env:LOCALAPPDATA "WindowsCare";if(-not(Test-Path $d)){New-Item -ItemType Directory -Path $d -Force|Out-Null};return (Join-Path $d "license.dat") }
   function Get-WCExpectedKey([string]$id){
      $sha=[Security.Cryptography.SHA256]::Create();try{$b=$sha.ComputeHash([Text.Encoding]::UTF8.GetBytes("WC9PRO-2026-MBG|"+$id));$h=([BitConverter]::ToString($b)).Replace("-","");return "WC9P-"+$h.Substring(0,4)+"-"+$h.Substring(4,4)+"-"+$h.Substring(8,4)+"-"+$h.Substring(12,4)}finally{$sha.Dispose()}
   }
   function Save-WCLicense([string]$key){
      try{
         Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
         $bytes=[Text.Encoding]::UTF8.GetBytes($key)
         $enc=[System.Security.Cryptography.ProtectedData]::Protect($bytes,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
         [IO.File]::WriteAllBytes((Get-WCLicensePath),$enc)
         return $true
      }catch{ return $false }
   }
   function Read-WCLicense {
      try{
         $p=Get-WCLicensePath;if(-not(Test-Path $p)){return $null}
         Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
         $enc=[IO.File]::ReadAllBytes($p)
         $b=[System.Security.Cryptography.ProtectedData]::Unprotect($enc,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
         return [Text.Encoding]::UTF8.GetString($b)
      }catch{return $null}
   }
   $licTitle=New-Object Windows.Forms.Label;$licTitle.Text="LICENÇA / ATIVAÇÃO";$licTitle.Location="28,28";$licTitle.Size="700,38";$licTitle.Font="Segoe UI,18,style=Bold";$licTitle.ForeColor="White";$tp.Controls.Add($licTitle)
   $licSub=New-Object Windows.Forms.Label;$licSub.Text="Windows Care 9.0 PRO: ativação local vinculada a esta instalação. A licença não altera os resultados do diagnóstico.";$licSub.Location="30,72";$licSub.Size="880,28";$licSub.ForeColor="Silver";$tp.Controls.Add($licSub)
   $iid=Get-WCInstallId;$expected=Get-WCExpectedKey $iid;$saved=Read-WCLicense;$active=($saved -eq $expected)
   $status=New-Object Windows.Forms.Label;$status.Location="30,120";$status.Size="500,36";$status.Font="Segoe UI,15,style=Bold";$status.Text=if($active){"ATIVADO"}else{"NÃO ATIVADO"};$status.ForeColor=if($active){"LightGreen"}else{"Orange"};$tp.Controls.Add($status)
   $idLab=New-Object Windows.Forms.Label;$idLab.Text="ID DA INSTALAÇÃO";$idLab.Location="30,180";$idLab.Size="220,24";$idLab.ForeColor="LightSkyBlue";$tp.Controls.Add($idLab)
   $idBox=New-Object Windows.Forms.TextBox;$idBox.Text=$iid;$idBox.Location="30,208";$idBox.Size="360,30";$idBox.ReadOnly=$true;$idBox.BackColor=[Drawing.Color]::FromArgb(31,39,49);$idBox.ForeColor="White";$tp.Controls.Add($idBox)
   $copy=New-Object Windows.Forms.Button;$copy.Text="COPIAR ID";$copy.Location="405,206";$copy.Size="120,32";$copy.BackColor=[Drawing.Color]::FromArgb(10,125,210);$copy.ForeColor="White";$copy.FlatStyle="Flat";$copy.Add_Click({[Windows.Forms.Clipboard]::SetText($idBox.Text);[Windows.Forms.MessageBox]::Show("ID da instalação copiado.","Licença",0,64)|Out-Null});$tp.Controls.Add($copy)
   $keyLab=New-Object Windows.Forms.Label;$keyLab.Text="CHAVE DE LICENÇA";$keyLab.Location="30,270";$keyLab.Size="220,24";$keyLab.ForeColor="LightSkyBlue";$tp.Controls.Add($keyLab)
   $keyBox=New-Object Windows.Forms.TextBox;$keyBox.Location="30,298";$keyBox.Size="495,30";$keyBox.CharacterCasing="Upper";$tp.Controls.Add($keyBox)
   if($active){$keyBox.Text=("WC9P-****-****-****-"+$saved.Substring($saved.Length-4));$keyBox.ReadOnly=$true}
   $act=New-Object Windows.Forms.Button;$act.Text="ATIVAR LICENÇA";$act.Location="30,350";$act.Size="180,40";$act.BackColor=[Drawing.Color]::FromArgb(10,125,210);$act.ForeColor="White";$act.FlatStyle="Flat";$tp.Controls.Add($act)
   $info=New-Object Windows.Forms.Label;$info.Location="30,410";$info.Size="850,100";$info.ForeColor="Gainsboro";$info.Text="A chave de licença é vinculada ao ID desta instalação e armazenada de forma protegida pelo Windows (DPAPI) para o usuário atual.`r`n`r`nA validação desta versão é local/offline.";$tp.Controls.Add($info)
   $act.Add_Click({$k=$keyBox.Text.Trim().ToUpperInvariant();if($k -eq (Get-WCExpectedKey (Get-WCInstallId))){if(Save-WCLicense $k){$status.Text="ATIVADO";$status.ForeColor="LightGreen";$keyBox.Text=("WC9P-****-****-****-"+$k.Substring($k.Length-4));$keyBox.ReadOnly=$true;[Windows.Forms.MessageBox]::Show("Windows Care 9.0 PRO ativado e licença salva nesta instalação.","Licença",0,64)|Out-Null}else{[Windows.Forms.MessageBox]::Show("A chave é válida, mas não foi possível salvar a ativação. Nenhuma ativação permanente foi registrada.","Licença",0,16)|Out-Null}}else{[Windows.Forms.MessageBox]::Show("Chave inválida para este ID de instalação.","Licença",0,48)|Out-Null}})
 }elseif($tabName -eq "Sobre"){
   $aboutTitle=New-Object Windows.Forms.Label;$aboutTitle.Text="WINDOWS CARE 9.0 PRO - FINAL 5";$aboutTitle.Location="28,30";$aboutTitle.Size="700,38";$aboutTitle.Font="Segoe UI,18,style=Bold";$aboutTitle.ForeColor="White";$tp.Controls.Add($aboutTitle)
   $aboutCredit=New-Object Windows.Forms.Label;$aboutCredit.Text="Desenvolvido por Marcelo Bertoni Galvão";$aboutCredit.Location="30,78";$aboutCredit.Size="700,28";$aboutCredit.Font="Segoe UI,11,style=Bold";$aboutCredit.ForeColor="LightSkyBlue";$tp.Controls.Add($aboutCredit)
   $aboutText=New-Object Windows.Forms.Label;$aboutText.Text="Diagnóstico, acompanhamento e manutenção conservadora do Windows.`r`n`r`n• 16 etapas de diagnóstico`r`n• Teste Rápido e Teste Completo`r`n• Painel de Saúde e Monitoramento`r`n• Histórico comparativo por RecordId`r`n• Relatório técnico e resumo para o usuário`r`n• Nenhum reparo automático de disco`r`n• Nota de hardware heurística — não é benchmark`r`n`r`nFINAL — atualização controlada com backup/rollback; licença persistente e motor de diagnóstico preservado.";$aboutText.Location="30,130";$aboutText.Size="850,330";$aboutText.Font="Segoe UI,11";$aboutText.ForeColor="Gainsboro";$tp.Controls.Add($aboutText)
   $uninstallBtn=New-Object Windows.Forms.Button;$uninstallBtn.Text="DESINSTALAR WINDOWS CARE";$uninstallBtn.Location="30,500";$uninstallBtn.Size="260,40";$uninstallBtn.ForeColor="White";$uninstallBtn.BackColor=[Drawing.Color]::FromArgb(55,35,35);$uninstallBtn.FlatStyle="Flat"
   $uninstallBtn.Add_Click({
      # Localiza o desinstalador de forma robusta. O Inno Setup pode usar
      # unins000.exe, unins001.exe etc., e o caminho oficial também fica no Registro.
      $u=$null
      $localUninstaller=Get-ChildItem -LiteralPath $PSScriptRoot -Filter "unins*.exe" -File -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -First 1
      if($localUninstaller){$u=$localUninstaller.FullName}

      if(-not $u){
         $regPaths=@(
            "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
            "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
            "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
         )
         foreach($rp in $regPaths){
            $entry=Get-ItemProperty $rp -ErrorAction SilentlyContinue | Where-Object {
               $_.DisplayName -like "Windows Care 9.0 PRO*"
            } | Select-Object -First 1
            if($entry -and $entry.UninstallString){
               $raw=[Environment]::ExpandEnvironmentVariables([string]$entry.UninstallString)
               if($raw -match '^\s*"([^"]+\.exe)"'){ $candidate=$matches[1] }
               elseif($raw -match '^\s*([^\s]+\.exe)'){ $candidate=$matches[1] }
               else{$candidate=$null}
               if($candidate -and (Test-Path -LiteralPath $candidate)){$u=$candidate;break}
            }
         }
      }

      if(-not $u){
         [Windows.Forms.MessageBox]::Show("O Windows Care não conseguiu localizar o desinstalador registrado pelo Windows.`r`n`r`nUse Configurações > Aplicativos > Aplicativos instalados > Windows Care 9.0 PRO.","Windows Care 9.0 PRO",[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information)|Out-Null
         return
      }

      $c=[Windows.Forms.MessageBox]::Show("Deseja desinstalar o Windows Care 9.0 PRO?","Desinstalar Windows Care",[Windows.Forms.MessageBoxButtons]::YesNo,[Windows.Forms.MessageBoxIcon]::Question)
      if($c -eq [Windows.Forms.DialogResult]::Yes){
         try{
            Start-Process -FilePath $u
            $DF.Close()
            $F.Close()
         }catch{
            [Windows.Forms.MessageBox]::Show("Não foi possível abrir o desinstalador.`r`n`r`n$($_.Exception.Message)","Windows Care 9.0 PRO",[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Error)|Out-Null
         }
      }
   });$tp.Controls.Add($uninstallBtn)
 }else{
   $tb=New-Object Windows.Forms.TextBox;$tb.Multiline=$true;$tb.ReadOnly=$true;$tb.ScrollBars="Vertical";$tb.Dock="Fill";$tb.BackColor=[Drawing.Color]::FromArgb(9,12,17);$tb.ForeColor="Gainsboro";$tb.Font="Consolas,10.5"
   $tp.Controls.Add($tb);$TechBoxes[$tabName]=$tb
 }
 $DT.TabPages.Add($tp)|Out-Null
}
$L=$TechBoxes["Log Completo"]
function Update-HistoryGrid {
 if(-not $HistoryGrid){return}
 $HistorySummaryLabel.Text=$script:HistorySummary
 $HistoryDetailLabel.Text=$script:HistoryDetail
 if($HistoryStatusLabel){$HistoryStatusLabel.Text=$script:HistoryStatus;$HistoryStatusLabel.ForeColor=if($script:HistoryStatus -eq "NOVOS EVENTOS"){"Orange"}elseif($script:HistoryStatus -eq "ESTÁVEL"){"LightGreen"}else{"LightSkyBlue"}}
 if($HistoryLastLabel){$HistoryLastLabel.Text=$script:HistoryLastOccurrence}
 if($HistoryEvolutionLabel){$HistoryEvolutionLabel.Text=$script:HistoryEvolution;$HistoryEvolutionLabel.ForeColor=if($script:HistoryStatus -eq "NOVOS EVENTOS"){"Orange"}else{"LightGreen"}}
 $HistorySummaryLabel.ForeColor=if($script:HistoryNew7 -gt 0){"Orange"}else{"LightSkyBlue"}
 $HistoryGrid.Rows.Clear()
 try{
   if(Test-Path $historyFile){
     $obj=Get-Content -LiteralPath $historyFile -Raw -ErrorAction Stop|ConvertFrom-Json
     $runs=@($obj.Runs|Select-Object -Last 10);[array]::Reverse($runs)
     foreach($r in $runs){
       try{$when=([datetime]$r.Timestamp).ToString("dd/MM/yyyy HH:mm")}catch{$when=([string]$r.Timestamp)}
       $mode=Normalize-WCHistoryMode ([string]$r.Mode);$score=if($r.HardwareScore -and ([string]$r.HardwareScore) -ne "-"){([string]$r.HardwareScore)+"/10"}else{"N/D"}
       $new7=if($null -ne $r.NewID7 -and ([string]$r.NewID7) -ne "-"){"+"+([string]$r.NewID7)}else{"N/D"}
       $dev=if($r.Model){(([string]$r.Model)+$(if($r.Letter){" "+([string]$r.Letter)}else{""}))}else{"N/D"}
       $idx=$HistoryGrid.Rows.Add($when,([string]$r.Health),$mode,$score,([string]$r.ID7),$new7,([string]$r.ID153),([string]$r.ID129),$dev)
       if($new7 -ne "N/D" -and [int]$r.NewID7 -gt 0){$HistoryGrid.Rows[$idx].DefaultCellStyle.ForeColor="Orange"}
     }
   }
 }catch{$HistorySummaryLabel.Text="Histórico indisponível: "+$_.Exception.Message;$HistorySummaryLabel.ForeColor="Tomato"}
}


function Update-HealthPanel([string[]]$raw){
 if($null -eq $HealthPanelValues -or $HealthPanelValues.Count -eq 0){return}

 function Set-HCard([string]$name,[string]$value,[string]$state){
   if(-not $HealthPanelValues.ContainsKey($name)){return}
   $obj=$HealthPanelValues[$name]
   $obj.Value.Text=$value
   if($value -match '^(OK|MUITO BOM|VERDE)' -or $state -match '^(DRIVERS E DISPOSITIVOS|SISTEMA|MEMÓRIA RAM|DEFENDER):\s*OK'){$color=[Drawing.Color]::LimeGreen}
   elseif($value -match '^(PRIORIDADE|ALERTA|ATENÇÃO|ATENCAO|LARANJA|AMARELO)' -or $state -match 'PRIORIDADE|ALERTA|ATENÇÃO|ATENCAO|LARANJA|AMARELO'){$color=[Drawing.Color]::Orange}
   elseif($value -match '^(INFO|NÃO DISPONÍVEL|NAO DISPONIVEL)' -or $state -match '^INFO'){$color=[Drawing.Color]::DeepSkyBlue}
   elseif($value -match '^(FALHA|ERRO)' -or $state -match '^(FALHA|ERRO)'){$color=[Drawing.Color]::Tomato}
   else{$color=[Drawing.Color]::Silver}
   $obj.Value.ForeColor=$color
   $obj.Bar.BackColor=$color
 }

 $sys=[string](@($raw|Where-Object{$_ -match '^SISTEMA:'}|Select-Object -First 1)[0])
 $note=[string](@($raw|Where-Object{$_ -match '^NOTA:'}|Select-Object -First 1)[0])
 $drv=[string](@($raw|Where-Object{$_ -match '^DRIVERS E DISPOSITIVOS:'}|Select-Object -First 1)[0])
 $mem=[string](@($raw|Where-Object{$_ -match '^MEMÓRIA RAM:'}|Select-Object -First 1)[0])
 $est=[string](@($raw|Where-Object{$_ -match '^ESTABILIDADE:'}|Select-Object -First 1)[0])
 $arm=[string](@($raw|Where-Object{$_ -match '^ARMAZENAMENTO:'}|Select-Object -First 1)[0])
 $def=[string](@($raw|Where-Object{$_ -match '^DEFENDER:'}|Select-Object -First 1)[0])
 $upd=[string](@($raw|Where-Object{$_ -match '^WINDOWS UPDATE:'}|Select-Object -First 1)[0])

 $overall=[string]$cards["Resumo de saúde"].Text
 $nval=if($note -match '^NOTA:\s*(.+)$'){$Matches[1]}else{"N/D"}
 $sval=if($sys -match '^SISTEMA:\s*([^-]+)'){$Matches[1].Trim()}else{"N/D"}
 $dval=if($drv -match '^DRIVERS E DISPOSITIVOS:\s*([^-]+)'){$Matches[1].Trim()}else{"N/D"}
 $mval=if($mem -match '^MEMÓRIA RAM:\s*([^-]+)'){$Matches[1].Trim()}else{"N/D"}
 $eval=if($est -match '^ESTABILIDADE:\s*([^-]+)'){$Matches[1].Trim()}else{"N/D"}
 $aval=if($arm -match '^ARMAZENAMENTO:\s*([^-]+)'){$Matches[1].Trim()}else{"N/D"}
 $fval=if($def -match '^DEFENDER:\s*([^-]+)'){$Matches[1].Trim()}else{"N/D"}
 $uval=if($upd -match '^WINDOWS UPDATE:\s*([^-]+)'){$Matches[1].Trim()}elseif($upd){$upd -replace '^WINDOWS UPDATE:\s*',''}else{"N/D"}

 Set-HCard "Saúde Geral" $overall $overall
 Set-HCard "Hardware" $nval $note
 Set-HCard "Sistema" $sval $sys
 Set-HCard "Drivers" $dval $drv
 Set-HCard "Memória" $mval $mem
 Set-HCard "Estabilidade" $eval $est
 Set-HCard "Armazenamento" $aval $arm
 Set-HCard "Microsoft Defender" $fval $def
 Set-HCard "Atualizações" $uval $upd
 $hpAttention=if($arm -match 'PRIORIDADE|ALERTA'){"Armazenamento requer prioridade: faça backup e investigue as evidências."}elseif($est -match 'ATENÇÃO|ATENCAO'){"Estabilidade merece acompanhamento: consulte os eventos registrados."}elseif($upd -match 'FALHA|ERRO|ATENÇÃO|ATENCAO'){"Windows Update requer atenção: consulte os detalhes do diagnóstico."}else{"Nenhuma prioridade crítica identificada no diagnóstico atual."}
 if($HealthPanelValues.ContainsKey("Atenção")){$HealthPanelValues["Atenção"].Value.Text=$hpAttention}
}


function Update-MonitorPanel([string[]]$raw){
 if($null -eq $MonitorValues -or $MonitorValues.Count -eq 0){return}
 function Set-Mon([string]$n,[string]$v,[string]$kind){
   if(-not $MonitorValues.ContainsKey($n)){return};$o=$MonitorValues[$n];$o.Value.Text=$v
   if($null -eq $o.Bar){return}
   if($kind -match 'NOVOS|PRIORIDADE|ALERTA|ATENÇÃO|ATENCAO|LARANJA|AMARELO'){$c=[Drawing.Color]::Orange}
   elseif($kind -match 'FALHA|ERRO'){$c=[Drawing.Color]::Tomato}
   elseif($kind -match 'ESTÁVEL|OK|MUITO BOM|VERDE'){$c=[Drawing.Color]::LimeGreen}
   elseif($kind -match 'INFO|NÃO DISPONÍVEL|NAO DISPONIVEL'){$c=[Drawing.Color]::DeepSkyBlue}else{$c=[Drawing.Color]::Silver}
   $o.Value.ForeColor=$c;$o.Bar.BackColor=$c
 }
 $mem=[string](@($raw|Where-Object{$_ -match '^MEMÓRIA RAM:'}|Select-Object -First 1)[0])
 $est=[string](@($raw|Where-Object{$_ -match '^ESTABILIDADE:'}|Select-Object -First 1)[0])
 $arm=[string](@($raw|Where-Object{$_ -match '^ARMAZENAMENTO:'}|Select-Object -First 1)[0])
 $ev=[string](@($raw|Where-Object{$_ -match '^RESUMO DE EVIDÊNCIAS:'}|Select-Object -First 1)[0])
 $def=[string](@($raw|Where-Object{$_ -match '^DEFENDER:'}|Select-Object -First 1)[0])
 $temps=@($raw|Where-Object{$_ -match '^TEMPERATURA ARMAZENAMENTO:'}|Select-Object -First 2)
 $tempText=if($temps.Count){($temps|ForEach-Object{if($_ -match 'TEMPERATURA ARMAZENAMENTO:\s*([^|]+)\|\s*Dispositivo=([^|]+)'){$Matches[2].Trim()+": "+$Matches[1].Trim()}else{$_}})-join " | "}else{"NÃO DISPONÍVEL"}
 $when=(Get-Date).ToString("dd/MM/yyyy HH:mm")
 try{if(Test-Path $historyFile){$ho=Get-Content -LiteralPath $historyFile -Raw|ConvertFrom-Json;$lr=@($ho.Runs|Select-Object -Last 1)[0];if($lr.Timestamp){$when=([datetime]$lr.Timestamp).ToString("dd/MM/yyyy HH:mm")}}}catch{}
 Set-Mon "Último diagnóstico" $when "INFO"
 Set-Mon "Evolução" ([string]$script:HistoryStatus) ([string]$script:HistoryStatus)
 $store=if($ev){($arm+" | "+($ev -replace '^RESUMO DE EVIDÊNCIAS:\s*',''))}else{$arm};Set-Mon "Armazenamento" ($store -replace '^ARMAZENAMENTO:\s*','') $arm
 Set-Mon "Temperaturas" $tempText $(if($temps.Count){"OK"}else{"INFO"})
 Set-Mon "Estabilidade" ($est -replace '^ESTABILIDADE:\s*','') $est
 Set-Mon "Memória" ($mem -replace '^MEMÓRIA RAM:\s*','') $mem
 Set-Mon "Segurança" ($def -replace '^DEFENDER:\s*','') $def
 # 9.0 Alpha 4.6 - espaço livre atual do volume do sistema. Apenas leitura.
 try{
   $sysDrive=Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction Stop
   if($sysDrive.Size -gt 0){$freeGB=[math]::Round($sysDrive.FreeSpace/1GB,1);$totalGB=[math]::Round($sysDrive.Size/1GB,1);$pct=[math]::Round(($sysDrive.FreeSpace/$sysDrive.Size)*100,0);$spaceText=("{0} GB livres de {1} GB ({2}%)" -f $freeGB,$totalGB,$pct);$spaceKind=if($pct -lt 10){"ATENÇÃO"}elseif($pct -lt 20){"INFO"}else{"OK"};Set-Mon "Espaço C:" $spaceText $spaceKind}else{Set-Mon "Espaço C:" "NÃO DISPONÍVEL" "INFO"}
 }catch{Set-Mon "Espaço C:" "NÃO DISPONÍVEL" "INFO"}
 # Tendência usa somente o histórico local das últimas execuções; não transforma contagens menores em melhora.
 $trendText="REFERÊNCIA";$trendKind="INFO"
 try{
   if(Test-Path $historyFile){$th=Get-Content -LiteralPath $historyFile -Raw|ConvertFrom-Json;$tr=@($th.Runs|Select-Object -Last 10);if($tr.Count -ge 2){$newSum=0;foreach($rr in $tr){$newSum += [int]$(if($null -ne $rr.NewID7){$rr.NewID7}else{0});$newSum += [int]$(if($null -ne $rr.NewID153){$rr.NewID153}else{0});$newSum += [int]$(if($null -ne $rr.NewID129){$rr.NewID129}else{0})};if($newSum -gt 0){$trendText=("{0} execução(ões) analisada(s) | {1} evento(s) novo(s) confirmado(s)" -f $tr.Count,$newSum);$trendKind="ATENÇÃO"}else{$trendText=("{0} execução(ões) analisada(s) | sem novos eventos confirmados" -f $tr.Count);$trendKind="ESTÁVEL"}}}
 }catch{$trendText="NÃO DISPONÍVEL";$trendKind="INFO"}
 Set-Mon "Tendência histórica" $trendText $trendKind
 $lastOccText=([string]$script:HistoryLastOccurrence -replace '^Última ocorrência registrada:\s*','')
 try{if($lastOccText -match '(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2})'){$lastDt=[datetime]::ParseExact($Matches[1],"dd/MM/yyyy HH:mm:ss",[Globalization.CultureInfo]::InvariantCulture);$span=(Get-Date)-$lastDt;if($span.TotalDays -ge 1){$lastOccText += (" | há {0} dia(s)" -f [math]::Floor($span.TotalDays))}elseif($span.TotalHours -ge 1){$lastOccText += (" | há {0} hora(s)" -f [math]::Floor($span.TotalHours))}}}catch{}
 Set-Mon "Última ocorrência" $lastOccText "INFO"
 $attention=if($arm -match 'PRIORIDADE|ALERTA'){"Armazenamento requer prioridade. Faça backup do disco citado e investigue as evidências. Nenhum reparo automático será executado."}elseif($est -match 'ATENÇÃO|ATENCAO'){"Estabilidade merece acompanhamento. Consulte os eventos registrados para contexto."}else{"Nenhum alerta principal novo identificado no diagnóstico atual."}
 $MonitorValues["Atenção"].Value.Text=$attention
}

function Update-TechTabs {
 if(!(Test-Path $log)){return}
 $raw=@(Get-Content -LiteralPath $log -ErrorAction SilentlyContinue)
 function FillTech([string]$name,[string[]]$patterns,[string]$empty){
   $sel=@()
   foreach($line in $raw){foreach($p in $patterns){if(([string]$line)-match $p){$sel += [string]$line;break}}}
   $target=$TechBoxes[$name]
   if($null -ne $target -and $target.PSObject.Properties.Name -contains 'Text'){
     $target.Text=if($sel.Count){$sel -join "`r`n"}else{$empty}
   }
 }
 FillTech "Resumo" @('^SISTEMA:','^HARDWARE:','^NOTA:','^DRIVERS E DISPOSITIVOS:','^MEMÓRIA RAM:','^TEMPERATURAS:','^BATERIA:','^ENERGIA:','^ESTABILIDADE:','^DISCOS:','^REDE:','^INICIALIZAÇÃO:','^ARMAZENAMENTO:','^DISPOSITIVO DE ARMAZENAMENTO AFETADO:','^RESUMO DE EVIDÊNCIAS:','^DEFENDER:') "Resumo ainda não disponível."
 FillTech "Hardware" @('^HARDWARE:','^NOTA:','^MEMÓRIA RAM:','^MÓDULO RAM ','^TEMPERATURA ','^TEMPERATURAS:','^BATERIA','^ENERGIA:') "Hardware: informação não disponível."
 FillTech "Drivers" @('^DRIVERS E DISPOSITIVOS:','^DRIVER/DISPOSITIVO ','^ORIENTAÇÃO DRIVERS:') "Drivers: nenhum detalhe adicional."
 FillTech "Armazenamento" @('^DISCOS:','^ARMAZENAMENTO:','^DISPOSITIVO DE ARMAZENAMENTO AFETADO:','^RESUMO DE EVIDÊNCIAS:','^INTERPRETAÇÃO ID ','^DISCO CITADO','^DISPOSITIVO DE ARMAZENAMENTO AFETADO:','^EVENTOS QUE CAUSARAM','^EVENTO [0-9]+:','^EVENTO [0-9]+ - Descrição:','^MAPEAMENTO ATUAL','^DISCO [0-9]+:','^RECOMENDAÇÃO:','^OBSERVAÇÃO:') "Armazenamento: nenhum detalhe adicional."
 FillTech "Estabilidade" @('^ESTABILIDADE:','^EVENTO ESTABILIDADE ','^INTERPRETAÇÃO ESTABILIDADE:') "Estabilidade: nenhum detalhe adicional."
 FillTech "Sistema" @('^SISTEMA:','^CHKDSK','^DISM ','^SFC ','^WINDOWS UPDATE:','^LIMPEZA:','^REDE:','^OTIMIZAÇÃO:','^INICIALIZAÇÃO:','^DEFENDER:') "Sistema: informação não disponível."
 Update-HistoryGrid
 Update-HealthPanel $raw
 Update-MonitorPanel $raw
 $logTarget=$TechBoxes["Log Completo"]
 if($null -ne $logTarget -and $logTarget.PSObject.Properties.Name -contains 'Text'){$logTarget.Text=$raw -join "`r`n"}
}
$D.Add_Click({Update-TechTabs;$DF.ShowDialog($F)|Out-Null})

function CardStatus($name,$status){
 if(-not $cards.ContainsKey($name)){return};$x=$cards[$name]
 $x.Text=$status
 if($cardBars.ContainsKey($name)){$cardBars[$name].BackColor=StatusBarColor $status}
 $x.ForeColor=switch($status){"OK"{"LightGreen"}"EXECUTANDO"{"LightSkyBlue"}"INFO"{"LightSkyBlue"}"ATENCAO"{"Gold"}"REINICIAR"{"Orange"}"TIMEOUT"{"Orange"}"FALHA"{"Tomato"}"ERRO"{"Tomato"}"CONCLUIDO"{"LightGreen"}default{"Silver"}}
}


function Sync-FinalCards {
 if(!(Test-Path $results)){return}
 $final=@(Get-Content -LiteralPath $results -ErrorAction SilentlyContinue)
 foreach($line in $final){
   $rp=$line -split '\|',4
   if($rp.Count -ge 3){
     $rn=$rp[1]; $rs=$rp[2]
     if($cards.ContainsKey($rn)){
       $cards[$rn].Text=$rs
       if($cardBars.ContainsKey($rn)){$cardBars[$rn].BackColor=StatusBarColor $rs}
       $cards[$rn].ForeColor=switch -Regex($rs){
         '^OK$'{"LightGreen";break}
         'MUITO BOM'{"LightGreen";break}
         '^VERDE$'{"LightGreen";break}
         '^AMARELO$'{"Gold";break}
         '^LARANJA$'{"Orange";break}
         '^VERMELHO$'{"Tomato";break}
         '^INFO$'{"LightSkyBlue";break}
         '^ALERTA$'{"LightSkyBlue";break}
         'ATENCAO'{"Gold";break}
         'REINICIAR|TIMEOUT'{"Orange";break}
         'FALHA|ERRO'{"Tomato";break}
         default{"LightSkyBlue"}
       }
     }
   }
 }
}

function Get-StorageDeviceText($sourceLines){
 $canonical=[string](@($sourceLines | Where-Object {([string]$_) -match '^DISPOSITIVO DE ARMAZENAMENTO AFETADO:'} | Select-Object -First 1))
 if($canonical -match '^DISPOSITIVO DE ARMAZENAMENTO AFETADO:\s*(.+?)\s*\|\s*Unidade\s*=\s*([^|]+)'){
   $model=$Matches[1].Trim()
   $unit=$Matches[2].Trim()
   if($model -and $unit){ return ("Dispositivo: {0} - {1}" -f $model,$unit) }
 }
 $legacy=[string](@($sourceLines | Where-Object {([string]$_) -match '^DISCO CITADO NOS EVENTOS:'} | Select-Object -First 1))
 if($legacy -match 'DISCO CITADO NOS EVENTOS:\s*Disco\s+\d+\s*\|\s*([^|]+?)\s*\|\s*Unidades=([^|]+)'){
   return ("Dispositivo: {0} - {1}" -f $Matches[1].Trim(),$Matches[2].Trim())
 }
 return "Dispositivo: identificação não confirmada pelo mapeamento atual"
}

function Build-Report([string]$health=""){
 $tech=@()
 if(Test-Path $log){$tech=@(Get-Content -LiteralPath $log -ErrorAction SilentlyContinue)}

 $lines=New-Object Collections.Generic.List[string]
 $lines.Add("============================================================================")
 $lines.Add("                       WINDOWS CARE 9.0 PRO - FINAL 5")
 $lines.Add("                    RELATÓRIO DE DIAGNÓSTICO DO SISTEMA")
 $lines.Add("                   Desenvolvido por Marcelo Bertoni Galvão")
 $lines.Add("============================================================================")
 $lines.Add("Data do diagnóstico: "+(Get-Date).ToString("dd/MM/yyyy HH:mm:ss"))
 $lines.Add("")
 $lines.Add("1. DIAGNÓSTICO GERAL")
 $lines.Add("----------------------------------------------------------------------------")
 $lines.Add("Saúde geral: "+$health)
 $lines.Add("Nota do hardware: "+$cards["Nota do hardware"].Text)
 $lines.Add("A nota de hardware é heurística e não substitui benchmark.")
 if($Quick.Checked){$lines.Add("Modo de Teste Rápido: ATIVO - etapas pesadas foram puladas. INFO indica etapa não executada neste modo, e não falha.")}
 $lines.Add("")
 $attention=@($names | Where-Object {$cards[$_].Text -in @("ATENCAO","ALERTA","REINICIAR","TIMEOUT","FALHA","ERRO")})
 $lines.Add("2. PONTOS DE ATENÇÃO")
 $lines.Add("----------------------------------------------------------------------------")
 if($attention.Count -eq 0){$lines.Add("Nenhum ponto de atenção identificado nos cards principais.")}
 else{foreach($a in $attention){$lines.Add("- "+$a+": "+$cards[$a].Text)}}
 $lines.Add("")
 $lines.Add("3. INTERPRETAÇÃO E ORIENTAÇÃO")
 $lines.Add("----------------------------------------------------------------------------")
 $lines.Add($Reason.Text)
 if($Advice){$lines.Add($Advice.Text)}
 $lines.Add("")
 
 $lines.Add("4. RESUMO PARA O USUÁRIO")
 $lines.Add("----------------------------------------------------------------------------")
 if($health -eq "VERDE"){
   $lines.Add("Situação: não foi encontrado alerta principal nas verificações executadas.")
   $lines.Add("Orientação: mantenha backups e a manutenção normal do Windows.")
 }elseif($health -eq "AMARELO"){
   $lines.Add("Situação: existe pelo menos um ponto que merece análise.")
   $lines.Add("Orientação: consulte os detalhes técnicos antes de realizar qualquer correção.")
 }elseif($health -eq "LARANJA"){
   $lines.Add("Situação: existe evidência importante registrada pelo Windows que requer prioridade de análise.")
   $lines.Add("Orientação: em PRIORIDADE ALTA - ARMAZENAMENTO, faça backup dos dados do disco citado e consulte os Detalhes Técnicos.")
   $lines.Add("Importante: PRIORIDADE ALTA indica evidência relevante registrada pelo Windows, mas não significa, por si só, que o dispositivo esteja definitivamente condenado.")
 }else{
   $lines.Add("Situação: consulte os detalhes técnicos para interpretar o resultado.")
 }
 if($Quick.Checked){
   $lines.Add("Observação: este relatório foi gerado em Modo de Teste Rápido; etapas pesadas foram puladas.")
 }
 $lines.Add("")
 
 $lines.Add("5. DIAGNÓSTICO EM DESTAQUE")
 $lines.Add("----------------------------------------------------------------------------")
 if($cards["Armazenamento"].Text -eq "ALERTA"){
   $diskLine=[string](@($tech | Where-Object {([string]$_) -match '^DISCO CITADO NOS EVENTOS:'} | Select-Object -First 1))
   $evidence=[string](@($tech | Where-Object {([string]$_) -match '^RESUMO DE EVIDÊNCIAS:'} | Select-Object -First 1))
   $lines.Add("Problema: PRIORIDADE ALTA - ARMAZENAMENTO com evidência importante registrada pelo Windows.")
   $lines.Add((Get-StorageDeviceText $tech))
   if($evidence){$lines.Add($evidence.Replace("RESUMO DE EVIDÊNCIAS:","Evidências:"))}
   $lines.Add("Ação recomendada: PRIORIDADE ALTA - faça backup dos dados do disco citado e consulte os Detalhes Técnicos.")
   $lines.Add("O Windows Care não executa reparo automático no disco.")
 }
 $lines.Add("")
 $lines.Add("6. RESULTADOS DAS 16 ETAPAS")


 $lines.Add("----------------------------------------------------------------------------")
 foreach($n in $names){$lines.Add(("{0,-28} {1}" -f $n,$cards[$n].Text))}
 $lines.Add("")
 $lines.Add("7. LEGENDA")
 $lines.Add("----------------------------------------------------------------------------")
 $lines.Add("OK       = verificação concluída sem alerta principal.")
 $lines.Add("INFO     = etapa informativa ou ação não executada automaticamente.")
 $lines.Add("ATENCAO  = merece análise; não confirma defeito físico por si só.")
 $lines.Add("ALERTA   = há evidência importante registrada pelo Windows; requer prioridade de análise.")
 $lines.Add("FALHA    = falha na coleta; não significa automaticamente falha do computador.")
 $lines.Add("TIMEOUT  = etapa excedeu o limite de segurança configurado.")
 $lines.Add("")
 $lines.Add("8. DIAGNÓSTICOS ADICIONAIS — WINDOWS CARE 9.0 PRO")
 $lines.Add("----------------------------------------------------------------------------")
 $driverLines=@($tech | Where-Object {([string]$_) -match '^(DRIVERS E DISPOSITIVOS:|DRIVER/DISPOSITIVO |ORIENTAÇÃO DRIVERS:)'})
 if($driverLines.Count -gt 0){
   foreach($dl in $driverLines){$lines.Add([string]$dl)}
 }else{
   $lines.Add("Drivers e dispositivos: informação não disponível.")
 }
 $lines.Add("")
 $ramLines=@($tech | Where-Object {([string]$_) -match '^(MEMÓRIA RAM:|MÓDULO RAM |MEMÓRIA - EVENTOS:|EVENTO MEMÓRIA )'})
 if($ramLines.Count -gt 0){
   foreach($rl in $ramLines){$lines.Add([string]$rl)}
 }else{
   $lines.Add("Memória RAM: informação não disponível.")
 }
 $lines.Add("")
 $tempLines=@($tech | Where-Object {([string]$_) -match '^TEMPERATURA'})
 if($tempLines.Count -gt 0){
   foreach($tl in $tempLines){$lines.Add([string]$tl)}
 }else{
   $lines.Add("Temperaturas: NÃO DISPONÍVEL - nenhuma leitura confiável coletada.")
 }
 $lines.Add("")
 $energyLines=@($tech | Where-Object {([string]$_) -match '^(BATERIA|ENERGIA:)'})
 if($energyLines.Count -gt 0){
   foreach($el in $energyLines){$lines.Add([string]$el)}
 }else{
   $lines.Add("Bateria e energia: informação não disponível.")
 }
 $lines.Add("")
 $stabilityLines=@($tech | Where-Object {([string]$_) -match '^(ESTABILIDADE:|EVENTO ESTABILIDADE |INTERPRETAÇÃO ESTABILIDADE:)'})
 if($stabilityLines.Count -gt 0){
   foreach($sl in $stabilityLines){$lines.Add([string]$sl)}
 }else{
   $lines.Add("Estabilidade: informação não disponível.")
 }
 $lines.Add("")
 $lines.Add("9. HISTÓRICO DE SAÚDE")
 $lines.Add("----------------------------------------------------------------------------")
 $lines.Add($script:HistorySummary)
 $lines.Add($script:HistoryDetail)
$lines.Add("Status comparativo: "+$script:HistoryStatus)
$lines.Add($script:HistoryLastOccurrence)
$lines.Add($script:HistoryEvolution)
 $lines.Add("")
 $lines.Add("Últimos diagnósticos (até 10):")
 try{
   if(Test-Path $historyFile){$ho=Get-Content -LiteralPath $historyFile -Raw|ConvertFrom-Json;$hr=@($ho.Runs|Select-Object -Last 10);[array]::Reverse($hr);foreach($r in $hr){try{$hd=([datetime]$r.Timestamp).ToString("dd/MM/yyyy HH:mm")}catch{$hd=([string]$r.Timestamp)};$hm=Normalize-WCHistoryMode ([string]$r.Mode);if(-not $r.Mode){$hm="Dados não disponíveis (versão anterior)"};$hs=if($r.HardwareScore -and ([string]$r.HardwareScore) -ne "-"){$r.HardwareScore+"/10"}else{"N/D (versão anterior)"};$h7=if($null -ne $r.NewID7 -and ([string]$r.NewID7) -ne "-"){"+"+$r.NewID7}else{"N/D"};$h153=if($null -ne $r.NewID153 -and ([string]$r.NewID153) -ne "-"){"+"+$r.NewID153}else{"N/D"};$h129=if($null -ne $r.NewID129 -and ([string]$r.NewID129) -ne "-"){"+"+$r.NewID129}else{"N/D"};$lines.Add(("{0} | Saúde={1} | Modo={2} | Nota={3} | ID7={4} (Novos {5}) | ID153={6} (Novos {7}) | ID129={8} (Novos {9}) | {10} {11}" -f $hd,$r.Health,$hm,$hs,$r.ID7,$h7,$r.ID153,$h153,$r.ID129,$h129,$r.Model,$r.Letter))}}
 }catch{$lines.Add("Histórico detalhado indisponível para o relatório.")}
 $lines.Add("Observação: a comparação identifica eventos novos já registrados pelo Windows; redução de contagem não é tratada automaticamente como melhora.")
 $lines.Add("")
 $lines.Add("10. MONITORAMENTO E EVOLUÇÃO")
 $lines.Add("----------------------------------------------------------------------------")
 $lines.Add("Estado da evolução: "+$script:HistoryStatus)
 $lines.Add($script:HistoryLastOccurrence)
 $lines.Add($script:HistoryEvolution)
 foreach($mp in @('^ARMAZENAMENTO:','^RESUMO DE EVIDÊNCIAS:','^ESTABILIDADE:','^MEMÓRIA RAM:','^DEFENDER:','^TEMPERATURA ARMAZENAMENTO:')){foreach($ml in @($tech|Where-Object{([string]$_)-match $mp}|Select-Object -First 2)){$lines.Add([string]$ml)}}
 $lines.Add("Interpretação: ESTÁVEL significa ausência de novos eventos confirmados desde a referência comparável; não significa que um alerta anterior foi resolvido.")
 $lines.Add("")
 $lines.Add("11. EVENTOS E DETALHES TÉCNICOS")
 $lines.Add("----------------------------------------------------------------------------")
 if(Test-Path $log){$lines.Add((Get-Content $log -Raw -ErrorAction SilentlyContinue))}
 else{$lines.Add("Log técnico não disponível.")}
 $lines.Add("")
 $lines.Add("============================================================================")
 $lines.Add("Desenvolvido por Marcelo Bertoni Galvão")
 $lines.Add("============================================================================")
 return ($lines -join [Environment]::NewLine)
}
function Save-AutoReport([string]$health){
 try{
   $desktop=[Environment]::GetFolderPath("Desktop")
   $script:autoReport=Join-Path $desktop ("Windows_Care_7.0_PRO_Relatorio_"+(Get-Date).ToString("dd-MM-yyyy_HH-mm-ss")+".txt")
   Build-Report $health | Set-Content -LiteralPath $script:autoReport -Encoding UTF8 -ErrorAction Stop
 }catch{
   $script:autoReport=$null
 }
}

$timer=New-Object Windows.Forms.Timer;$timer.Interval=300;$last="";$lastLog="";$totalStart=Get-Date;$stageStart=Get-Date;$script:engineProc=$null;$script:currentStage=0;$script:resultLines=0
$timer.Add_Tick({
 if(Test-Path $results){
   $rl=@(Get-Content $results -ErrorAction SilentlyContinue)
   if($rl.Count -gt $script:resultLines){
     for($i=$script:resultLines;$i -lt $rl.Count;$i++){
       $rp=$rl[$i] -split '\|',4
       if($rp.Count -ge 3){
         $rn=$rp[1];$rs=$rp[2]
         if($cards.ContainsKey($rn)){
           $cards[$rn].Text=$rs
           $cards[$rn].ForeColor=switch -Regex($rs){
             '^OK$'{"LightGreen";break}
             'MUITO BOM'{"LightGreen";break}
             '^VERDE$'{"LightGreen";break}
             '^AMARELO$'{"Gold";break}
             '^LARANJA$'{"Orange";break}
             '^VERMELHO$'{"Tomato";break}
             'ATENCAO'{"Gold";break}
             'REINICIAR|TIMEOUT'{"Orange";break}
             'FALHA|ERRO'{"Tomato";break}
             default{"LightSkyBlue"}
           }
         }
       }
     }
     $script:resultLines=$rl.Count
   }
 }

 if(Test-Path $state){$stateRaw=Read-StateSafe $state -ErrorAction SilentlyContinue;$raw=if($null -ne $stateRaw){([string]$stateRaw).Trim()}else{""}
  if($raw-and$raw-ne$script:last){$a=$raw-split'\|',6;if($a.Count-ge5){$n=[int]$a[0];$script:currentStage=$n;$name=$a[1];$pct=[int]$a[2];$status=$a[3];$detail=$a[4];$S.Text="Etapa $n de 16 • $name";$P.Value=[math]::Min(100,[math]::Max(0,$pct));$Q.Text="$($P.Value)%";if($cards.ContainsKey($name) -and $cards[$name].Text -eq "AGUARDANDO"){CardStatus $name "ANALISANDO"};$script:stageStart=Get-Date;$script:last=$raw
   if($status-eq"CONCLUIDO"){
     $P.Value=100;$Q.Text="100%"
     Sync-FinalCards
     $health=$cards["Resumo de saúde"].Text
     if($health -notin @("VERDE","AMARELO","LARANJA","VERMELHO")){
       $health="AMARELO"
       if(Test-Path $results){
         $rr=@(Get-Content $results -ErrorAction SilentlyContinue | Where-Object {$_ -match '^16\|Resumo de saúde\|'})
         if($rr.Count -gt 0){$hp=$rr[-1] -split '\|',4;if($hp.Count-ge3){$health=$hp[2]}}
       }
     }
     # FINAL: prioridade final de saúde baseada no estado real dos cards.
     if(@($names | Where-Object {$cards[$_].Text -eq "ALERTA"}).Count -gt 0){
       $health="LARANJA"
     }
     $cards["Resumo de saúde"].Text=$health
     $cards["Resumo de saúde"].ForeColor=if($health-eq"VERDE"){"LightGreen"}elseif($health-eq"AMARELO"){"Gold"}elseif($health-eq"LARANJA"){"Orange"}else{"Tomato"}
     $H.Text="Saúde do PC: $health";$H.ForeColor=$cards["Resumo de saúde"].ForeColor
     $attention=@($names | Where-Object {$cards[$_].Text -in @("ATENCAO","ALERTA","REINICIAR","TIMEOUT","FALHA","ERRO")})
     if($attention.Count -eq 0){
       $Reason.Text="Nenhum ponto de atenção identificado nos cards principais."
     } elseif($attention.Count -eq 1 -and $attention[0] -eq "Armazenamento"){
       $storageDetail=""
       if(Test-Path $results){
         $sr=@(Get-Content $results -ErrorAction SilentlyContinue | Where-Object {$_ -match '^14\|Armazenamento\|'})
         if($sr.Count -gt 0){$sp=$sr[-1] -split '\|',4;if($sp.Count-ge4){$storageDetail=$sp[3]}}
       }
       if($storageDetail){$Reason.Text="1 item requer atenção: Armazenamento - $storageDetail"}
       else{$Reason.Text="1 item requer atenção: Armazenamento."}
     } elseif($attention.Count -eq 1){
       $Reason.Text="1 item requer atenção: $($attention[0])."
     } else {
       $Reason.Text="$($attention.Count) itens requerem atenção: "+($attention -join ", ")
     }
     $Reason.ForeColor=$cards["Resumo de saúde"].ForeColor

     if($attention.Count -eq 0){
       $Advice.Text="Nenhuma ação corretiva principal é indicada pelos resultados."
       $Advice.ForeColor="LightGreen"
     } elseif($attention -contains "Armazenamento"){
       $Advice.Text="PRIORIDADE ALTA - ARMAZENAMENTO: faça backup do disco citado e consulte Detalhes Técnicos. O Windows Care apresenta evidências registradas pelo Windows e não executa reparos automáticos."
       $Advice.ForeColor="Gold"
     } else {
       $Advice.Text="Há item(ns) que requerem análise. Consulte os detalhes técnicos antes de realizar alterações."
       $Advice.ForeColor="Gold"
     }

     $B.Enabled=$true;$R.Enabled=$true;$Pdf.Enabled=$true
     
     if($health -eq "LARANJA"){
       $cards["Resumo de saúde"].ForeColor="Orange"
     }

     
     # FINAL - Painel final simplificado para o usuário
     $DiagPanel.Visible=$false

     if($cards["Armazenamento"].Text -eq "ALERTA"){
       $diskLine=@($tech | Where-Object {$_ -like "DISCO CITADO NOS EVENTOS:*"} | Select-Object -First 1)
       $device="Dispositivo: consulte Detalhes técnicos"
       if($diskLine){
         $raw=[string]$diskLine
         if($raw -match 'Disco\s+\d+\s+\|\s+([^|]+)\|\s+Unidades=([^|]+)'){
           $device=("Dispositivo: {0} - {1}" -f $Matches[1].Trim(),$Matches[2].Trim())
         }
       }
       $id7Line=@($tech | Where-Object {$_ -like "RESUMO DE EVIDÊNCIAS:*"} | Select-Object -First 1)
       $qty=""
       if($id7Line -and ([string]$id7Line -match 'ID 7=(\d+)')){$qty=$Matches[1]}
       $DiagTitle.Text=if($qty){"PRIORIDADE ALTA - ARMAZENAMENTO - $qty erro(s) ID 7"}else{"PRIORIDADE ALTA - ARMAZENAMENTO"}
       $DiagDevice.Text=$device
       $DiagAction.Text="Ação recomendada: faça backup dos dados e consulte os detalhes técnicos. Nenhum reparo automático será executado."
       $DiagPanel.Visible=$true

     }elseif($health -eq "AMARELO"){
       $DiagTitle.Text="EXISTE UM PONTO QUE MERECE ANÁLISE"
       $DiagDevice.Text="Consulte os resultados destacados em amarelo."
       $DiagAction.Text="Ação recomendada: revise os detalhes antes de realizar qualquer correção."
       $DiagPanel.Visible=$true

     }elseif($health -eq "VERDE"){
       $DiagTitle.ForeColor="LightGreen"
       $DiagTitle.Text="NENHUM ALERTA PRINCIPAL IDENTIFICADO"
       $DiagDevice.Text="As verificações executadas não encontraram alerta principal."
       $DiagAction.Text="Mantenha backups e a manutenção normal do Windows."
       $DiagPanel.Visible=$true

     }

     
     # FINAL - painel final sem sobreposição e com dispositivo identificado
     $DiagPanel.Visible=$false
     if($cards["Armazenamento"].Text -eq "ALERTA"){
       $device=Get-StorageDeviceText $tech
       $qty=""
       $evLine=[string](@($tech | Where-Object {([string]$_) -match '^RESUMO DE EVIDÊNCIAS:'} | Select-Object -First 1))
       if($evLine -match 'ID 7=(\d+)'){$qty=$Matches[1]}
       $DiagTitle.ForeColor="Orange"
       $DiagTitle.Text=if($qty){"PRIORIDADE ALTA - ARMAZENAMENTO - $qty erro(s) ID 7"}else{"PRIORIDADE ALTA - ARMAZENAMENTO"}
       $DiagDevice.Text=$device
       $DiagAction.Text="Ação: faça backup do disco citado e consulte Detalhes Técnicos.`r`nNenhum reparo automático será executado."
       $DiagPanel.Visible=$true

     }elseif($health -eq "AMARELO"){
       $DiagTitle.ForeColor="Yellow"
       $DiagTitle.Text="EXISTE UM PONTO QUE MERECE ANÁLISE"
       $DiagDevice.Text="Consulte os resultados destacados em amarelo."
       $DiagAction.Text="Ação recomendada: revise os detalhes antes de realizar qualquer correção."
       $DiagPanel.Visible=$true

     }elseif($health -eq "VERDE"){
       $DiagTitle.ForeColor="LightGreen"
       $DiagTitle.Text="NENHUM ALERTA PRINCIPAL IDENTIFICADO"
       $DiagDevice.Text="As verificações executadas não encontraram alerta principal."
       $DiagAction.Text="Mantenha backups e a manutenção normal do Windows."
       $DiagPanel.Visible=$true

     }

     
     # FINAL - painel final único, alimentado pelo log técnico real.
     $DiagPanel.Visible=$false
     $techFinal=@()
     if(Test-Path $log){$techFinal=@(Get-Content -LiteralPath $log -ErrorAction SilentlyContinue)}

     if($cards["Armazenamento"].Text -eq "ALERTA"){
       $device=Get-StorageDeviceText $techFinal

       $qty=""
       $evLine=[string](@($techFinal | Where-Object {([string]$_) -match '^RESUMO DE EVIDÊNCIAS:'} | Select-Object -First 1))
       if($evLine -match 'ID 7=(\d+)'){$qty=$Matches[1]}

       $DiagTitle.ForeColor="Orange"
       $DiagTitle.Text=if($qty){"PRIORIDADE ALTA - ARMAZENAMENTO - $qty erro(s) ID 7"}else{"PRIORIDADE ALTA - ARMAZENAMENTO"}
       $DiagDevice.Text=$device
       $DiagAction.Text="Ação: faça backup do disco citado e consulte Detalhes Técnicos.`r`nNenhum reparo automático será executado."
       $DiagPanel.Visible=$true


     }elseif($health -eq "AMARELO"){
       $DiagTitle.ForeColor="Yellow"
       $DiagTitle.Text="EXISTE UM PONTO QUE MERECE ANÁLISE"
       $DiagDevice.Text="Consulte os resultados destacados em amarelo."
       $DiagAction.Text="Ação recomendada: revise os detalhes antes de realizar qualquer correção."
       $DiagPanel.Visible=$true

     }elseif($health -eq "VERDE"){
       $DiagTitle.ForeColor="LightGreen"
       $DiagTitle.Text="NENHUM ALERTA PRINCIPAL IDENTIFICADO"
       $DiagDevice.Text="As verificações executadas não encontraram alerta principal."
       $DiagAction.Text="Mantenha backups e a manutenção normal do Windows."
       $DiagPanel.Visible=$true

     }

Update-HealthHistory $health
     if($script:HistoryNew7 -gt 0){$HistoryIndicator.Text="Histórico: +$($script:HistoryNew7) novo(s) evento(s) ID 7 desde o último diagnóstico.";$HistoryIndicator.ForeColor="Orange"}else{$HistoryIndicator.Text="Histórico: Nenhum novo evento ID 7 desde o último diagnóstico.";$HistoryIndicator.ForeColor="LightGreen"}
     Update-TechTabs
     Save-AutoReport $health
     $timer.Stop()
   }
   elseif($status-eq"ERRO"){
     $H.Text="Saúde do PC: ERRO";$H.ForeColor="Tomato"
     $Reason.Text="O diagnóstico foi interrompido por uma falha inesperada. Consulte Detalhes técnicos."
     $Reason.ForeColor="Tomato"
     if($P.Value -ge 100){$P.Value=99;$Q.Text="INTERROMPIDO"}
     $B.Enabled=$true;$R.Enabled=$true;$Pdf.Enabled=$false;$timer.Stop()
   }
  }}
 }
 if(Test-Path $log){$t=Get-Content $log -Raw -ErrorAction SilentlyContinue;if($t-ne$script:lastLog){$L.Text=$t;$L.SelectionStart=$L.TextLength;$L.ScrollToCaret();$script:lastLog=$t;Update-TechTabs}}
 $elapsedStage=((Get-Date)-$script:stageStart)
 if($Quick.Checked -and $script:currentStage -ge 1 -and $script:currentStage -le 4 -and $elapsedStage.TotalSeconds -gt 90){
   if($script:engineProc -and -not $script:engineProc.HasExited){try{$script:engineProc.Kill()}catch{}}
   $msg="FALHA NA COLETA: etapa rápida sem resposta por mais de 90 segundos."
   $L.AppendText($msg+"`r`n")
   $H.Text="Saúde do PC: FALHA NA COLETA";$H.ForeColor="Tomato"
   if($cards.ContainsKey($name)){$cards[$name].Text="FALHA";$cards[$name].ForeColor="Tomato";if($cardBars.ContainsKey($name)){$cardBars[$name].BackColor=StatusBarColor "FALHA"}}
   $B.Enabled=$true;$R.Enabled=$true;$Pdf.Enabled=$false;$timer.Stop()
 }
 $TE.Text="Etapa: "+$elapsedStage.ToString("hh\:mm\:ss");$TT.Text="Total: "+((Get-Date)-$script:totalStart).ToString("hh\:mm\:ss")
})
$B.Add_Click({
$script:CurrentRunId=[guid]::NewGuid().ToString("N")
$DiagPanel.Visible=$false
$DiagTitle.Text=""
$DiagDevice.Text=""
$DiagAction.Text=""
 Remove-Item $state,$log,$results -Force -ErrorAction SilentlyContinue;foreach($x in $cards.Values){$x.Text="AGUARDANDO";$x.ForeColor="Silver"};foreach($b in $cardBars.Values){$b.BackColor=StatusBarColor "AGUARDANDO"};$L.Clear();$script:last="";$script:lastLog="";$script:resultLines=0;$script:totalStart=Get-Date;$script:stageStart=$script:totalStart;$P.Value=1;$Q.Text="1%";$S.Text="Etapa 1 de 16 • Sistema";$H.Text="Saúde do PC: ANALISANDO";$H.ForeColor="White";$Reason.Text="Executando as verificações do Windows Care...";$Reason.ForeColor="Silver";$HistoryIndicator.Text="Histórico: comparando com o diagnóstico anterior...";$HistoryIndicator.ForeColor="Silver";if($Advice){$Advice.Text="Aguardando a conclusão das verificações...";$Advice.ForeColor="Silver"};$B.Enabled=$false;$R.Enabled=$false;$Pdf.Enabled=$false;CardStatus "Sistema" "EXECUTANDO"
 $arg="-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$engine`" -StateFile `"$state`" -LogFile `"$log`" -ResultsFile `"$results`""
 try{
   if($Quick.Checked){
     $arg += " -QuickMode"
     $script:engineProc=Start-Process -FilePath "powershell.exe" -ArgumentList $arg -WindowStyle Hidden -PassThru -ErrorAction Stop
   }else{
     # O diagnóstico completo exige elevação para CHKDSK /scan, DISM e SFC.
     # Eleva somente o motor; a GUI permanece aberta e acompanha os arquivos de estado.
     $script:engineProc=Start-Process -FilePath "powershell.exe" -ArgumentList $arg -Verb RunAs -WindowStyle Hidden -PassThru -ErrorAction Stop
   }
   $timer.Start()
 }catch{
   $H.Text="Saúde do PC: FALHA NA COLETA";$H.ForeColor="Tomato"
   $Reason.Text="Diagnóstico completo não iniciado. A autorização de administrador foi cancelada ou falhou.";$Reason.ForeColor="Tomato"
   $B.Enabled=$true;$R.Enabled=$true;$Pdf.Enabled=$false
   $L.AppendText(("FALHA NA COLETA: não foi possível iniciar o motor com os privilégios necessários. " + $_.Exception.Message + "`r`n"))
 }
})
function HtmlEncode([string]$t){ if($null -eq $t){return ""}; return [System.Net.WebUtility]::HtmlEncode($t) }
function Build-ProfessionalHtml([string]$health){
  $mode=if($Mode){[string]$Mode.SelectedItem}else{"USUÁRIO"}
  $report=@(Build-Report $health)
  $hw=[string]$cards['Nota do hardware'].Text
  $sys=[string]$cards['Sistema'].Text
  $storage=[string]$cards['Armazenamento'].Text
  $defender=[string]$cards['Microsoft Defender'].Text
  $orientation=[string]$Advice.Text
  $healthClass=switch -Regex ($health){'VERDE|OK'{'ok'};'LARANJA|ALERTA|ATEN'{'warn'};'VERMELHO|FALHA'{'bad'};default{'info'}}
  if($mode -eq "USUÁRIO"){
    $body=@"
<div class="grid">
  <div class="card"><span>Hardware</span><strong>$(HtmlEncode $hw)</strong></div>
  <div class="card"><span>Sistema</span><strong>$(HtmlEncode $sys)</strong></div>
  <div class="card"><span>Armazenamento</span><strong>$(HtmlEncode $storage)</strong></div>
  <div class="card"><span>Microsoft Defender</span><strong>$(HtmlEncode $defender)</strong></div>
</div>
<section><h2>Diagnóstico principal</h2><div class="orientation">$(HtmlEncode $orientation)</div></section>
<section><h2>Como interpretar</h2><p>Este relatório resume evidências coletadas pelo Windows Care. Alertas indicam pontos que merecem atenção e investigação; não significam, isoladamente, falha física definitiva.</p></section>
"@
  } else {
    $body="<section><h2>Detalhes técnicos</h2><pre>$(HtmlEncode ($report -join "`r`n"))</pre></section>"
  }
  $date=(Get-Date).ToString('dd/MM/yyyy HH:mm:ss')
  return @" 
<!doctype html><html><head><meta charset="utf-8"><style>
@page{size:A4;margin:15mm 14mm 15mm 14mm}*{box-sizing:border-box}body{font-family:Segoe UI,Arial,sans-serif;margin:0;color:#17212b;background:#fff;font-size:12px;line-height:1.45}.top{background:#101820;color:#fff;padding:22px 24px;border-radius:10px}.top h1{margin:0;font-size:25px;letter-spacing:.3px}.meta{color:#cbd7e3;margin-top:5px;font-size:11px}.health{margin-top:18px;padding:14px 16px;border-left:6px solid #f2a900;background:#f5f7f9;border-radius:6px}.health small{display:block;color:#5b6773;text-transform:uppercase;font-weight:600}.health strong{font-size:22px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px}.card{border:1px solid #d7e0e8;border-radius:7px;padding:12px 14px;min-height:64px}.card span{display:block;color:#5b6773;font-size:10px;text-transform:uppercase;margin-bottom:5px}.card strong{font-size:14px}section{margin-top:18px}h2{font-size:15px;color:#1676b8;border-bottom:1px solid #d7e0e8;padding-bottom:6px;margin-bottom:10px}.orientation{background:#fff8e5;border-left:5px solid #f2a900;padding:12px 14px;border-radius:5px}pre{white-space:pre-wrap;font-family:Consolas,monospace;font-size:9px;line-height:1.35;background:#f5f7f9;padding:14px;border-radius:6px}.notice{margin-top:18px;padding:10px 12px;background:#f5f7f9;border-radius:6px;color:#44515e;font-size:10.5px}.footer{margin-top:22px;border-top:1px solid #d7e0e8;padding-top:10px;display:flex;justify-content:space-between;color:#5b6773;font-size:9.5px}
</style></head><body>
<div class="top"><h1>WINDOWS CARE 9.0 PRO</h1><div class="meta">Relatório profissional de saúde do PC • $date • Modo $(HtmlEncode $mode)</div></div>
<div class="health"><small>Saúde geral</small><strong>$(HtmlEncode $health)</strong></div>
$body
<div class="notice"><strong>Nota importante:</strong> a nota de hardware é heurística e não substitui benchmark. O Windows Care não executa reparo automático de disco.</div>
<div class="footer"><span>Desenvolvido por Marcelo Bertoni Galvão</span><span>Windows Care 9.0 PRO • FINAL</span></div>
</body></html>
"@
}
function Export-ProfessionalPdf([string]$health){
  $d=New-Object Windows.Forms.SaveFileDialog;$d.Title="Salvar relatório PDF do Windows Care";$d.Filter="Documento PDF (*.pdf)|*.pdf";$d.DefaultExt="pdf";$d.AddExtension=$true;$d.FileName="Windows_Care_9.0_PRO_$((Get-Date).ToString('dd-MM-yyyy_HH-mm-ss')).pdf"
  if($d.ShowDialog($F)-ne [Windows.Forms.DialogResult]::OK){return}
  try{
    $html=Build-ProfessionalHtml $health
    $tmp=Join-Path $env:TEMP ("WindowsCare_"+[guid]::NewGuid().ToString('N')+".html")
    [IO.File]::WriteAllText($tmp,$html,(New-Object Text.UTF8Encoding($false)))
    # Localização robusta do Microsoft Edge: instalações por máquina, usuário, App Paths e PATH.
    $edgeCandidates=New-Object System.Collections.Generic.List[string]
    if(${env:ProgramFiles(x86)}){[void]$edgeCandidates.Add((Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'))}
    if($env:ProgramFiles){[void]$edgeCandidates.Add((Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'))}
    if($env:LOCALAPPDATA){[void]$edgeCandidates.Add((Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'))}
    foreach($rk in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe')){
      try{$rp=(Get-ItemProperty -LiteralPath $rk -ErrorAction Stop).'(default)';if($rp){[void]$edgeCandidates.Add([string]$rp)}}catch{}
    }
    try{$cmd=Get-Command msedge.exe -ErrorAction Stop;if($cmd.Source){[void]$edgeCandidates.Add([string]$cmd.Source)}}catch{}
    $edge=$edgeCandidates|Where-Object{$_ -and (Test-Path -LiteralPath $_ -PathType Leaf)}|Select-Object -Unique|Select-Object -First 1
    if(-not $edge){throw "Microsoft Edge não foi localizado nos caminhos padrão, App Paths ou PATH. O PDF não foi gerado."}
    $uri=(New-Object Uri($tmp)).AbsoluteUri
    $args=@('--headless','--disable-gpu','--no-pdf-header-footer',('--print-to-pdf='+$d.FileName),$uri)
    $pr=Start-Process -FilePath $edge -ArgumentList $args -WindowStyle Hidden -PassThru -Wait
    Start-Sleep -Milliseconds 300
    Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    if(-not (Test-Path -LiteralPath $d.FileName)){throw "O Edge não criou o arquivo PDF."}
    [Windows.Forms.MessageBox]::Show("Relatório PDF salvo com sucesso.`r`n`r`n$($d.FileName)","Windows Care 9.0 PRO",[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information)|Out-Null
  }catch{[Windows.Forms.MessageBox]::Show("Não foi possível gerar o PDF.`r`n`r`n$($_.Exception.Message)","Windows Care 9.0 PRO",[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Error)|Out-Null}
}
$Mode.Add_SelectedIndexChanged({
  if($Mode.SelectedItem -eq "USUÁRIO"){$D.Text="DETALHES TÉCNICOS";$AdviceTitle.Text="ORIENTAÇÃO"}
  else{$D.Text="CENTRAL TÉCNICA";$AdviceTitle.Text="ORIENTAÇÃO TÉCNICA"}
})
$Pdf.Add_Click({Export-ProfessionalPdf $cards["Resumo de saúde"].Text})

$R.Add_Click({
 $health=$cards["Resumo de saúde"].Text
 $d=New-Object Windows.Forms.SaveFileDialog
 $d.Title="Salvar relatório do Windows Care"
 $d.Filter="Relatório de texto (*.txt)|*.txt|Todos os arquivos (*.*)|*.*"
 $d.DefaultExt="txt"
 $d.AddExtension=$true
 $d.FileName="Windows_Care_7.0_PRO_Relatorio_$((Get-Date).ToString('dd-MM-yyyy_HH-mm-ss')).txt"
 if($d.ShowDialog($F)-eq [Windows.Forms.DialogResult]::OK){
   try{
     Build-Report $health | Set-Content -LiteralPath $d.FileName -Encoding UTF8 -ErrorAction Stop
     [Windows.Forms.MessageBox]::Show("Relatório salvo com sucesso.`r`n`r`n$($d.FileName)","Windows Care 9.0 PRO",[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information)|Out-Null
   }catch{
     [Windows.Forms.MessageBox]::Show("Não foi possível salvar o relatório.`r`n`r`n$($_.Exception.Message)","Windows Care 9.0 PRO",[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Error)|Out-Null
   }
 }
})
$DiagPanel=New-Object System.Windows.Forms.Panel
$DiagPanel.Location=New-Object Drawing.Point(455,600)
$DiagPanel.Size=New-Object Drawing.Size(495,124)
$DiagPanel.BackColor=[Drawing.Color]::FromArgb(27,35,44)
$DiagPanel.Visible=$true
$F.Controls.Add($DiagPanel)

$DiagHeader=New-Object System.Windows.Forms.Label
$DiagHeader.Location=New-Object Drawing.Point(12,6)
$DiagHeader.Size=New-Object Drawing.Size(470,19)
$DiagHeader.Text="DIAGNÓSTICO PRINCIPAL"
$DiagHeader.ForeColor="LightSkyBlue"
$DiagHeader.Font=New-Object Drawing.Font("Segoe UI",9,[Drawing.FontStyle]::Bold)

$DiagPanel.Controls.Add($DiagHeader)

$DiagTitle=New-Object System.Windows.Forms.Label
$DiagTitle.Location=New-Object Drawing.Point(12,28)
$DiagTitle.Size=New-Object Drawing.Size(470,19)
$DiagTitle.Font=New-Object Drawing.Font("Segoe UI",9,[Drawing.FontStyle]::Bold)
$DiagTitle.ForeColor="Orange"
$DiagPanel.Controls.Add($DiagTitle)

$DiagDevice=New-Object System.Windows.Forms.Label
$DiagDevice.Location=New-Object Drawing.Point(12,51)
$DiagDevice.Size=New-Object Drawing.Size(470,19)
$DiagDevice.ForeColor="White"
$DiagPanel.Controls.Add($DiagDevice)

$DiagAction=New-Object System.Windows.Forms.Label
$DiagAction.Location=New-Object Drawing.Point(12,74)
$DiagAction.Size=New-Object Drawing.Size(470,44)
$DiagAction.ForeColor="Khaki"
$DiagAction.AutoEllipsis=$false
$DiagAction.AutoSize=$false
$DiagPanel.Controls.Add($DiagAction)

# FINAL - estado inicial do painel de diagnóstico
$DiagTitle.Text="AGUARDANDO DIAGNÓSTICO"
$DiagTitle.ForeColor="LightSkyBlue"
$DiagDevice.Text="Inicie uma verificação para obter a análise do computador."
$DiagAction.Text="O Windows Care exibirá aqui a orientação principal após a análise."
$DiagAction.ForeColor="Silver"

$F.ShowDialog()