﻿param(
 [Parameter(Mandatory=$true)][string]$InstallDir,
 [Parameter(Mandatory=$true)][string]$PayloadDir,
 [Parameter(Mandatory=$true)][string]$Launcher,
 [Parameter(Mandatory=$true)][int]$ParentPid
)
$ErrorActionPreference='Stop'

# Windows Care 9.0 PRO - autoelevacao do atualizador
# Necessaria para substituir arquivos instalados em C:\Program Files.
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if(-not $isAdmin){
  try{
    function Quote-PS([string]$v){
      if($null -eq $v){ return "''" }
      return "'" + $v.Replace("'","''") + "'"
    }

    $self = $PSCommandPath
    if([string]::IsNullOrWhiteSpace($self)){
      throw 'Nao foi possivel localizar o script do atualizador para elevacao.'
    }

    $cmd = "& " + (Quote-PS $self) +
           " -InstallDir " + (Quote-PS $InstallDir) +
           " -PayloadDir " + (Quote-PS $PayloadDir) +
           " -Launcher " + (Quote-PS $Launcher) +
           " -ParentPid " + $ParentPid

    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($cmd))

    Start-Process -FilePath 'powershell.exe' `
      -Verb RunAs `
      -ArgumentList @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-EncodedCommand',$encoded) `
      -ErrorAction Stop | Out-Null

    # A instancia sem privilegios termina; a instancia elevada continua a atualizacao.
    exit 0
  }catch{
    Add-Type -AssemblyName System.Windows.Forms
    [Windows.Forms.MessageBox]::Show(
      "O Windows Care precisa de permissao de Administrador para atualizar arquivos em Program Files.`r`n`r`nErro: $($_.Exception.Message)",
      'Windows Care Updater 9.0 PRO',
      0,
      16
    ) | Out-Null
    exit 1
  }
}
$base=Join-Path $env:LOCALAPPDATA 'WindowsCare'
$backupRoot=Join-Path $base 'UpdateBackups'
New-Item -ItemType Directory -Path $backupRoot -Force|Out-Null
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$backup=Join-Path $backupRoot ('backup_'+$stamp)
$log=Join-Path $base ('updater_'+$stamp+'.log')
function Log([string]$m){("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$m)|Out-File -FilePath $log -Append -Encoding utf8}
function Show-Info([string]$message,[string]$title='Windows Care Updater 9.0 PRO'){
 Add-Type -AssemblyName System.Windows.Forms
 [Windows.Forms.MessageBox]::Show($message,$title,0,64)|Out-Null
}
function Show-Error([string]$message,[string]$title='Windows Care Updater 9.0 PRO'){
 Add-Type -AssemblyName System.Windows.Forms
 [Windows.Forms.MessageBox]::Show($message,$title,0,16)|Out-Null
}
try{
 Log 'Windows Care Updater FINAL iniciado.'
 Log "InstallDir: $InstallDir"
 Log "PayloadDir: $PayloadDir"
 Log "ParentPid: $ParentPid"

 if(-not(Test-Path -LiteralPath $InstallDir)){throw 'Pasta de instalação não localizada.'}
 if(-not(Test-Path -LiteralPath $PayloadDir)){throw 'Payload não localizado.'}
 $marker=Join-Path $PayloadDir 'WINDOWS_CARE_UPDATE_PAYLOAD.txt'
 if(-not(Test-Path -LiteralPath $marker)){throw 'Marcador do payload ausente.'}

 # Lê a versão esperada diretamente do marcador do payload.
 $markerText=Get-Content -LiteralPath $marker -Raw -ErrorAction Stop
 $expectedVersion=''
 $expectedDisplay=''
 if($markerText -match '(?m)^Version=(.+)$'){$expectedVersion=$matches[1].Trim()}
 if($markerText -match '(?m)^DisplayVersion=(.+)$'){$expectedDisplay=$matches[1].Trim()}
 if([string]::IsNullOrWhiteSpace($expectedVersion)){throw 'O marcador do payload não informa Version.'}
 if([string]::IsNullOrWhiteSpace($expectedDisplay)){throw 'O marcador do payload não informa DisplayVersion.'}
 Log "Versão esperada: $expectedDisplay ($expectedVersion)"

 # Garante que a instância que iniciou o updater realmente terminou antes de copiar.
 Log 'Aguardando o Windows Care encerrar.'
 $deadline=(Get-Date).AddSeconds(12)
 while((Get-Date) -lt $deadline){
   $p=Get-Process -Id $ParentPid -ErrorAction SilentlyContinue
   if($null -eq $p){break}
   Start-Sleep -Milliseconds 300
 }
 $p=Get-Process -Id $ParentPid -ErrorAction SilentlyContinue
 if($null -ne $p){
   Log 'A instância anterior permaneceu aberta; encerrando somente o processo do Windows Care que iniciou esta atualização.'
   Stop-Process -Id $ParentPid -Force -ErrorAction Stop
   Start-Sleep -Milliseconds 800
 }
 if($null -ne (Get-Process -Id $ParentPid -ErrorAction SilentlyContinue)){throw 'Não foi possível encerrar a instância anterior do Windows Care.'}

 # Backup completo antes de qualquer substituição.
 New-Item -ItemType Directory -Path $backup -Force|Out-Null
 Log "Backup: $backup"
 Get-ChildItem -LiteralPath $InstallDir -Force | ForEach-Object {
   if($_.Name -notlike 'GERADOR_LICENCA*'){ 
     Copy-Item -LiteralPath $_.FullName -Destination $backup -Recurse -Force -ErrorAction Stop
   }
 }
 Log 'Backup concluído.'

 # Aplica somente o conteúdo do payload. LocalAppData/licença não é tocado.
 Get-ChildItem -LiteralPath $PayloadDir -Force | ForEach-Object {
   if($_.Name -ne 'WINDOWS_CARE_UPDATE_PAYLOAD.txt'){
     Copy-Item -LiteralPath $_.FullName -Destination $InstallDir -Recurse -Force -ErrorAction Stop
   }
 }
 Log 'Arquivos do payload aplicados.'

 # Validação pós-cópia: script principal instalado anuncia a versão do payload.
 # O launcher .BAT é opcional: alguns instaladores não o copiam para Program Files.
 $mainScript=Join-Path $InstallDir 'Windows_Care_GUI_9.0_PRO_FINAL.ps1'
 if(-not(Test-Path -LiteralPath $mainScript)){throw 'Script principal não localizado após a atualização.'}
 $installedText=Get-Content -LiteralPath $mainScript -Raw -ErrorAction Stop
 if($installedText -notmatch [regex]::Escape($expectedDisplay)){
   throw "Validação pós-cópia falhou: o script instalado não identifica a versão $expectedDisplay."
 }
 Log 'Validação pós-cópia aprovada.'

 # Só agora reinicia a aplicação. Se o BAT existir, usa-o; caso contrário, inicia o PS1 principal.
 if(-not([string]::IsNullOrWhiteSpace($Launcher)) -and (Test-Path -LiteralPath $Launcher)){
   Log "Reabrindo pelo launcher: $Launcher"
   $newProc=Start-Process -FilePath $Launcher -WorkingDirectory $InstallDir -PassThru -ErrorAction Stop
 }else{
   Log 'Launcher BAT ausente; reabrindo diretamente pelo PowerShell.'
   $newProc=Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$mainScript+'"')) -WorkingDirectory $InstallDir -PassThru -ErrorAction Stop
 }
 Start-Sleep -Seconds 3
 if($newProc.HasExited){throw "A nova versão encerrou logo após iniciar (código $($newProc.ExitCode))."}
 Log "Nova versão iniciada. PID $($newProc.Id)."
 Show-Info "Atualização concluída com sucesso.`r`n`r`nVersão aplicada: $expectedDisplay`r`n`r`nBackup: $backup"
 exit 0
}catch{
 $msg=$_.Exception.Message
 Log ('FALHA: '+$msg)
 $rollbackOk=$false
 try{
   if(Test-Path -LiteralPath $backup){
     Log 'Iniciando rollback.'
     Get-ChildItem -LiteralPath $backup -Force | ForEach-Object {
       Copy-Item -LiteralPath $_.FullName -Destination $InstallDir -Recurse -Force -ErrorAction Stop
     }
     $rollbackOk=$true
     Log 'Rollback concluído.'
   }
 }catch{Log ('FALHA NO ROLLBACK: '+$_.Exception.Message)}
 $rb=if($rollbackOk){'Rollback concluído.'}else{'Rollback não pôde ser confirmado.'}
 Show-Error "A atualização falhou.`r`n`r`nErro: $msg`r`n`r`n$rb`r`n`r`nLog: $log"
 if($rollbackOk){
   try{
     if(-not([string]::IsNullOrWhiteSpace($Launcher)) -and (Test-Path -LiteralPath $Launcher)){
       Start-Process -FilePath $Launcher -WorkingDirectory $InstallDir -ErrorAction SilentlyContinue|Out-Null
     }elseif(Test-Path -LiteralPath (Join-Path $InstallDir 'Windows_Care_GUI_9.0_PRO_FINAL.ps1')){
       $rbMain=Join-Path $InstallDir 'Windows_Care_GUI_9.0_PRO_FINAL.ps1'
       Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoLogo','-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$rbMain+'"')) -WorkingDirectory $InstallDir -ErrorAction SilentlyContinue|Out-Null
     }
   }catch{}
 }
 exit 1
}
