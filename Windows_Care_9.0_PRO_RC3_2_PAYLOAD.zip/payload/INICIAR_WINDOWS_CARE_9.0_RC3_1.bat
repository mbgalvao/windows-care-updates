@echo off
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Windows_Care_GUI_9.0_PRO_RC3.ps1"
if errorlevel 1 (echo. & echo ERRO: Windows Care foi encerrado com codigo %errorlevel%. & pause)
