param(
 [Parameter(Mandatory=$true)][string]$InstallDir,
 [Parameter(Mandatory=$true)][string]$PayloadDir,
 [Parameter(Mandatory=$true)][string]$Launcher,
 [Parameter(Mandatory=$true)][int]$ParentPid
)
$ErrorActionPreference='Stop'
$base=Join-Path $env:LOCALAPPDATA 'WindowsCare'
$backupRoot=Join-Path $base 'UpdateBackups'
New-Item -ItemType Directory -Path $backupRoot -Force|Out-Null
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
$backup=Join-Path $backupRoot ('backup_'+$stamp)
$log=Join-Path $base ('updater_'+$stamp+'.log')
function Log([string]$m){("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$m)|Out-File -FilePath $log -Append -Encoding utf8}
try{
 Log 'Aguardando o Windows Care encerrar.'
 try{Wait-Process -Id $ParentPid -Timeout 30 -ErrorAction SilentlyContinue}catch{}
 Start-Sleep -Milliseconds 700
 if(-not(Test-Path $InstallDir)){throw 'Pasta de instalação não localizada.'}
 if(-not(Test-Path $PayloadDir)){throw 'Payload não localizado.'}
 $marker=Join-Path $PayloadDir 'WINDOWS_CARE_UPDATE_PAYLOAD.txt'
 if(-not(Test-Path $marker)){throw 'Marcador do payload ausente.'}
 New-Item -ItemType Directory -Path $backup -Force|Out-Null
 Log "Backup: $backup"
 Get-ChildItem -LiteralPath $InstallDir -Force | ForEach-Object {
   if($_.Name -notin @('GERADOR_LICENCA_RC1_SOMENTE_PROPRIETARIO.ps1')){Copy-Item -LiteralPath $_.FullName -Destination $backup -Recurse -Force}
 }
 Log 'Backup concluído.'
 Get-ChildItem -LiteralPath $PayloadDir -Force | ForEach-Object {
   if($_.Name -ne 'WINDOWS_CARE_UPDATE_PAYLOAD.txt'){Copy-Item -LiteralPath $_.FullName -Destination $InstallDir -Recurse -Force}
 }
 Log 'Arquivos do payload aplicados.'
 if(-not(Test-Path $Launcher)){throw 'Launcher da nova versão não localizado após atualização.'}
 Log 'Validação mínima concluída. Reiniciando.'
 Start-Process -FilePath $Launcher -WorkingDirectory $InstallDir
 Add-Type -AssemblyName System.Windows.Forms
 [Windows.Forms.MessageBox]::Show("Atualização concluída com sucesso.`r`n`r`nBackup: $backup","Windows Care Updater RC3.1",0,64)|Out-Null
}catch{
 $msg=$_.Exception.Message; Log ('FALHA: '+$msg)
 try{
   if(Test-Path $backup){
     Log 'Iniciando rollback.'
     Get-ChildItem -LiteralPath $backup -Force | ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination $InstallDir -Recurse -Force}
     Log 'Rollback concluído.'
   }
 }catch{Log ('FALHA NO ROLLBACK: '+$_.Exception.Message)}
 Add-Type -AssemblyName System.Windows.Forms
 [Windows.Forms.MessageBox]::Show("A atualização falhou e o Windows Care tentou restaurar o backup.`r`n`r`nErro: $msg`r`n`r`nLog: $log","Windows Care Updater RC3.1",0,16)|Out-Null
 if(Test-Path $Launcher){Start-Process -FilePath $Launcher -WorkingDirectory $InstallDir}
 exit 1
}
